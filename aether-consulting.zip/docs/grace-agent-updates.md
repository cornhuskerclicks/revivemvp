# Grace AI Agent Updates

This document contains the code changes needed in your Grace AI agent project to fix the issues identified.

## Issues to Fix

1. ✅ Chat bubble overlay - FIXED (removed custom bubble)
2. ✅ Chat widget styling - FIXED (added CSS in globals.css)
3. ⚠️ AI responses too general - NEEDS UPDATE in Grace project
4. ⚠️ Enter key doesn't work - NEEDS UPDATE in Grace project

## Required Changes in Grace Agent Project

### 1. Update System Prompt

Replace Grace's system prompt with the content from `docs/grace-system-prompt.md`. This will ensure Grace focuses on Aether's services and follows the proper tone and guidelines.

**Location:** Wherever you configure Grace's system prompt (likely in an API route or configuration file)

### 2. Add Enter Key Support

Add this code to Grace's chat input component to enable Enter key submission:

\`\`\`tsx
// In your chat input component (likely in components/chat-input.tsx or similar)

"use client"

import { useState, KeyboardEvent } from "react"

export function ChatInput({ onSend }: { onSend: (message: string) => void }) {
  const [message, setMessage] = useState("")

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    // Submit on Enter, but allow Shift+Enter for new lines
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      if (message.trim()) {
        onSend(message)
        setMessage("")
      }
    }
  }

  const handleSubmit = () => {
    if (message.trim()) {
      onSend(message)
      setMessage("")
    }
  }

  return (
    <div className="flex gap-2 p-4 border-t">
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Type a message..."
        className="flex-1 resize-none rounded-lg border p-3 focus:outline-none focus:ring-2 focus:ring-primary"
        rows={1}
      />
      <button
        onClick={handleSubmit}
        className="px-6 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
      >
        Send
      </button>
    </div>
  )
}
\`\`\`

### 3. Improve Chat Widget Styling

The Aether site now has CSS that will automatically style your Grace widget. However, you can also add these classes to your Grace components for better control:

\`\`\`tsx
// In your chat widget component

export function ChatWidget() {
  return (
    <div id="grace-chat-container" className="fixed bottom-6 right-6 z-50">
      {/* Chat button */}
      <button
        className="chat-widget-button"
        data-chat-widget
      >
        Chat
      </button>

      {/* Chat window */}
      <div
        role="dialog"
        className="chat-widget-window"
        data-chat-widget
      >
        <header className="chat-header">
          <h2>Grace - Aether Consulting</h2>
        </header>

        {/* Messages */}
        <div className="messages">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={msg.role === "user" ? "message-user" : "message-assistant"}
              data-role={msg.role}
            >
              {msg.content}
            </div>
          ))}
        </div>

        {/* Input */}
        <ChatInput onSend={handleSend} />
      </div>
    </div>
  )
}
\`\`\`

### 4. Update Grace's Knowledge Base

Grace should have access to the knowledge base API endpoint:

**API Endpoint:** `https://your-aether-site.vercel.app/api/knowledge`

Configure Grace to call this endpoint when she needs information about Aether Consulting, or copy the content from `docs/grace-system-prompt.md` directly into Grace's system prompt.

## Testing Checklist

After making these changes:

- [ ] Grace responds with Aether-focused answers
- [ ] Enter key submits messages (Shift+Enter for new lines)
- [ ] Chat widget matches Aether's cyan brand color
- [ ] Chat window has proper dark theme styling
- [ ] No overlapping chat buttons
- [ ] Grace asks for contact info when appropriate
- [ ] Grace directs users to book consultations

## Deployment

After updating the Grace agent code:

1. Commit and push changes to your Grace repository
2. Vercel will automatically redeploy
3. The widget.js will be updated
4. Test on the Aether site to confirm all fixes work
