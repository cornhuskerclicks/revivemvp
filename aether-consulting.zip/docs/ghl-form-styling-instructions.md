# GoHighLevel Form Styling Instructions

## Problem: Iframe Security Restrictions

The GHL form is loaded in an iframe from a different domain (`api.leadconnectorhq.com`), which means we cannot style its internal content directly from the Aether website due to browser security policies (same-origin policy).

## Solution: Add Custom CSS in GoHighLevel

To make the GHL form match the Aether brand styling, you need to add custom CSS directly in the GoHighLevel form builder.

### Step-by-Step Instructions:

1. **Log into GoHighLevel**
   - Go to your GHL dashboard
   - Navigate to Sites > Funnels/Websites

2. **Open Your Form**
   - Find the form "Aether Consulting Main" (ID: AZSFNPw0mlMaHcZSk9BM)
   - Click to edit it

3. **Access Custom CSS Settings**
   - Look for Settings or Advanced Settings
   - Find the "Custom CSS" or "Custom Code" section
   - This is usually in the form settings or style settings

4. **Add the Custom CSS**
   - Open the file `/public/ghl-form-styles.css` from this project
   - Copy the entire CSS content
   - Paste it into the Custom CSS field in GHL

5. **Save and Republish**
   - Save your form settings
   - Republish or update the form
   - The styling should now match the Aether brand

### What the Updated CSS Does:

- **Dark Background**: Forces black background on all elements with multiple selector strategies
- **Input Styling**: Semi-transparent white backgrounds (rgba(255, 255, 255, 0.05)) with subtle borders
- **Cyan Accents**: Uses #00D9FF (Aether's primary color) for focus states, buttons, and required asterisks
- **Typography**: White text on all labels and inputs for proper contrast
- **Hover Effects**: Smooth transitions with cyan glow on focus
- **Phone Input**: Specific styling for international phone number selector
- **Override Protection**: Uses !important flags to override GHL's default styles
- **Responsive**: Mobile-friendly with proper font sizing to prevent zoom on iOS

### Key Color Values:

- Background: `#000000` (black)
- Text: `#FFFFFF` (white)
- Primary/Accent: `#00D9FF` (cyan)
- Input Background: `rgba(255, 255, 255, 0.05)` (5% white)
- Input Border: `rgba(255, 255, 255, 0.1)` (10% white)
- Focus Border: `#00D9FF` (cyan)
- Focus Shadow: `rgba(0, 217, 255, 0.1)` (10% cyan)
- Placeholder Text: `rgba(156, 163, 175, 1)` (gray-400)

### Alternative: Use GHL's Built-in Theme Editor

If GHL doesn't support custom CSS or you prefer a visual editor:

1. Use GHL's theme/style editor
2. Match these colors:
   - Background: #000000 (black)
   - Text: #FFFFFF (white)
   - Primary/Accent: #00D9FF (cyan)
   - Input Background: rgba(255, 255, 255, 0.05)
   - Input Border: rgba(255, 255, 255, 0.1)

### Testing:

After applying the CSS:
1. Visit your contact page
2. Scroll to the "Alternative Form" section
3. The GHL form should now match the styling of the original form above it

### Troubleshooting:

- **Styles not applying**: Make sure you saved and republished the form in GHL
- **Some elements not styled**: GHL may use different class names - inspect the form and adjust selectors
- **Form looks broken**: Check for CSS conflicts in GHL's default styles
- **Still looks different**: GHL may have restrictions on certain style properties

## Contact

If you need help implementing these styles in GoHighLevel, contact your GHL support or the Aether development team.
