# Zapier/Make Integration Setup

## Overview
The contact form now submits to `/api/zap` which forwards submissions to Zapier or Make.com for automation workflows.

## Setup Steps

### 1. Create Webhook in Zapier/Make

**For Zapier:**
1. Create a new Zap
2. Choose "Webhooks by Zapier" as the trigger
3. Select "Catch Hook"
4. Copy the webhook URL provided

**For Make:**
1. Create a new scenario
2. Add a "Webhooks" module
3. Choose "Custom webhook"
4. Copy the webhook URL provided

### 2. Add Environment Variable

Add the webhook URL to your Vercel project:

1. Go to your Vercel project settings
2. Navigate to Environment Variables
3. Add one of these variables:
   - `ZAPIER_WEBHOOK_URL` (for Zapier)
   - `MAKE_WEBHOOK_URL` (for Make)
4. Paste your webhook URL as the value
5. Deploy your changes

### 3. Test the Integration

1. Submit a test form on your contact page
2. Check your Zapier/Make dashboard to see if the data was received
3. The webhook will receive these fields:
   - `name` - Contact's full name
   - `company` - Company name (optional)
   - `email` - Email address
   - `phone` - Phone number (optional)
   - `message` - Message content
   - `interests` - Comma-separated list (e.g., "Leadership, AI, Marketing")

### 4. Build Your Automation

Once the webhook is receiving data, you can:
- Send email notifications
- Add contacts to your CRM
- Create tasks in project management tools
- Send Slack notifications
- And much more!

## Security Features

- **Honeypot Protection**: The API includes honeypot fields to catch spam bots
- **Server-side Processing**: All submissions are processed server-side for security
- **Error Handling**: Graceful error handling with user-friendly messages

## Troubleshooting

If submissions aren't working:
1. Check that the environment variable is set correctly in Vercel
2. Verify the webhook URL is active in Zapier/Make
3. Check the browser console and Vercel logs for errors
4. Test the webhook URL directly with a tool like Postman
