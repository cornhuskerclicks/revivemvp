"use client"

export function ProofSection() {
  const companies = [
    { name: "Smith Pauley", logo: "/images/brands/smith-pauley.webp" },
    { name: "Summit Performance", logo: "/images/brands/summit-performance.webp" },
    { name: "America's Next Top Model", logo: "/images/brands/top-model.jpg" },
    { name: "Perez Hilton", logo: "/images/brands/perez-hilton.jpg" },
    { name: "Soft Card", logo: "/images/brands/soft-card.png" },
    { name: "Refinery29", logo: "/images/brands/refinery29.png" },
    { name: "Nebraska Stadium", logo: "/images/brands/nebraska-stadium.webp" },
    { name: "KSI", logo: "/images/brands/ksi.jpg" },
    { name: "People's Revolution", logo: "/images/brands/peoples-revolution.webp" },
    { name: "ChemTec", logo: "/images/brands/chemtec.svg" },
    { name: "The Coop", logo: "/images/brands/the-coop.png" },
    { name: "Noire Ink London", logo: "/images/brands/noire-ink.webp" },
    { name: "Party Pieces", logo: "/images/brands/party-pieces.png" },
    { name: "NR", logo: "/images/brands/nr-icon.png" },
    { name: "Sprout Social", logo: "/images/brands/sprout-social.png" },
  ]

  return (
    <section className="bg-black py-20 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Gradient overlays for fade effect */}
        <div className="relative">
          <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-black to-transparent z-10" />
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black to-transparent z-10" />

          <div className="flex animate-scroll gap-8">
            {/* First set of logos */}
            {companies.map((company, index) => (
              <div
                key={`first-${index}`}
                className="flex-shrink-0 w-56 h-32 bg-gray-900/30 border border-white/10 rounded-xl flex items-center justify-center p-6 transition-all duration-300 hover:border-primary hover:bg-gray-800/50 hover:scale-105"
              >
                <img
                  src={company.logo || "/placeholder.svg"}
                  alt={company.name}
                  className="max-w-full max-h-full object-contain opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0"
                />
              </div>
            ))}
            {/* Duplicate set for seamless loop */}
            {companies.map((company, index) => (
              <div
                key={`second-${index}`}
                className="flex-shrink-0 w-56 h-32 bg-gray-900/30 border border-white/10 rounded-xl flex items-center justify-center p-6 transition-all duration-300 hover:border-primary hover:bg-gray-800/50 hover:scale-105"
              >
                <img
                  src={company.logo || "/placeholder.svg"}
                  alt={company.name}
                  className="max-w-full max-h-full object-contain opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        .animate-scroll {
          animation: scroll 40s linear infinite;
        }

        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </section>
  )
}
