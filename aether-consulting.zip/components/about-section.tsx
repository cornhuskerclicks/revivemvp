"use client"

import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export function AboutSection() {
  const router = useRouter()

  const highlights = [
    "Proven Fractional CMOs & AI Experts",
    "StoryBrand + 3C Storytelling Certified",
    "Results-driven, data-informed marketing",
  ]

  return (
    <section id="about" className="bg-black py-20 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="font-heading font-bold text-white text-3xl md:text-4xl lg:text-5xl mb-8 uppercase">
          The Aether Advantage
        </h2>

        <p className="text-white text-lg md:text-xl mb-12 leading-relaxed text-pretty">
          Aether Consulting unites leadership, intelligence, and execution.
          <br />
          We align vision with systems and scale with precision.
        </p>

        <div className="space-y-4 mb-12">
          {highlights.map((highlight, index) => (
            <div key={index} className="flex items-center justify-center gap-3">
              <div className="text-primary w-6 h-6 flex-shrink-0 flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
                  <polyline points="20,6 9,17 4,12"></polyline>
                </svg>
              </div>
              <span className="text-white text-lg">{highlight}</span>
            </div>
          ))}
        </div>

        <Button
          onClick={() => router.push("/about")}
          className="border-2 border-primary bg-transparent text-white px-8 py-4 text-lg rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
        >
          Meet the Founders
        </Button>
      </div>
    </section>
  )
}
