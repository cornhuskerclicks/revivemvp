"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function AISection() {
  const benefits = [
    {
      icon: <div className="w-12 h-12 text-primary text-4xl flex items-center justify-center">💼</div>,
      title: "Automate Workflows",
      description: "Automate repetitive workflows",
    },
    {
      icon: <div className="w-12 h-12 text-primary text-4xl flex items-center justify-center">⏰</div>,
      title: "Save Time",
      description: "Save 10–40 hours per week",
    },
    {
      icon: <div className="w-12 h-12 text-primary text-4xl flex items-center justify-center">💰</div>,
      title: "Reduce Costs",
      description: "Reduce operating costs fast",
    },
    {
      icon: <div className="w-12 h-12 text-primary text-4xl flex items-center justify-center">🤖</div>,
      title: "No-Code AI",
      description: "No-code AI, built around your business",
    },
  ]

  const solutions = [
    {
      icon: <div className="w-8 h-8 text-primary text-2xl flex items-center justify-center">👥</div>,
      title: "Lead Qualifier AI",
      description:
        "Automate the initial screening of leads, ensuring your sales team focuses only on high-potential prospects.",
    },
    {
      icon: <div className="w-8 h-8 text-primary text-2xl flex items-center justify-center">📅</div>,
      title: "Appointment Setting AI",
      description: "Let AI handle scheduling, rescheduling, and reminders, freeing up your team for client engagement.",
    },
    {
      icon: <div className="w-8 h-8 text-primary text-2xl flex items-center justify-center">📄</div>,
      title: "Admin/Back Office AI",
      description: "Automate data entry, document processing, and routine administrative tasks to slash overhead.",
    },
    {
      icon: <div className="w-8 h-8 text-primary text-2xl flex items-center justify-center">🔍</div>,
      title: "Listening AI & Lead Scouting",
      description:
        "Our AI scours online groups and platforms to identify keywords, trends, and conversations, finding qualified leads with no ad spend.",
    },
    {
      icon: <div className="w-8 h-8 text-primary text-2xl flex items-center justify-center">🤖</div>,
      title: "AI Sales Agent & Reactivation",
      description:
        "Deploy an AI sales agent to reactivate dead leads in your database, nurture prospects, and close sales efficiently.",
    },
    {
      icon: <div className="w-8 h-8 text-primary text-2xl flex items-center justify-center">⚙️</div>,
      title: "Custom AI Systems",
      description:
        "Tailored AI solutions built from the ground up to address your unique business challenges and goals.",
    },
  ]

  const testimonials = [
    {
      quote: "Aether AI helped us cut down on manual tasks significantly. Highly recommend!",
      author: "CEO, Tech Startup",
    },
    {
      quote: "Their custom AI solutions are a game-changer for our operations.",
      author: "Operations Director, B2B Services",
    },
    {
      quote: "Seamless integration and excellent support. Our team loves the new AI tools.",
      author: "Founder, E-commerce Brand",
    },
  ]

  return (
    <section id="ai" className="bg-black py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* AI Hero Section */}
        <div className="text-center mb-20">
          <h2 className="font-heading font-bold text-white text-4xl md:text-5xl lg:text-6xl mb-6 uppercase">
            Aether AI
          </h2>
          <p className="text-muted-foreground text-xl md:text-2xl mb-8 max-w-4xl mx-auto leading-relaxed">
            We help 6-8 figure businesses automate operations, slash overhead, and scale effortlessly by building their
            own AI employees — no coding required.
          </p>
          <Button className="border-2 border-primary bg-transparent text-white px-8 py-4 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200">
            Book Free AI Audit →
          </Button>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {benefits.map((benefit, index) => (
            <div key={index} className="text-center">
              <div className="flex justify-center mb-4">{benefit.icon}</div>
              <h3 className="font-heading font-bold text-white text-xl mb-2 uppercase">{benefit.title}</h3>
              <p className="text-muted-foreground">{benefit.description}</p>
            </div>
          ))}
        </div>

        {/* Trusted By Section */}
        <div className="text-center mb-20">
          <h3 className="font-heading font-bold text-white text-2xl md:text-3xl mb-4 uppercase">
            Trusted by Industry Leaders
          </h3>
          <p className="text-muted-foreground text-lg">
            Join the companies already transforming their operations with AI
          </p>
        </div>

        {/* AI Solutions */}
        <div className="mb-20">
          <h3 className="font-heading font-bold text-white text-3xl md:text-4xl text-center mb-4 uppercase">
            Our AI Solutions
          </h3>
          <p className="text-muted-foreground text-xl text-center mb-12">Deploy your AI teammate in days.</p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {solutions.map((solution, index) => (
              <Card
                key={index}
                className="bg-black border-white border-2 rounded-lg transition-all duration-300 hover:border-primary hover:-translate-y-1"
              >
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {solution.icon}
                    <h4 className="font-heading font-bold text-white text-lg ml-3 uppercase">{solution.title}</h4>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{solution.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Success Story */}
        <div className="mb-20">
          <h3 className="font-heading font-bold text-white text-3xl md:text-4xl text-center mb-12 uppercase">
            Success Story
          </h3>

          <Card className="bg-black border-primary border-2 rounded-lg max-w-4xl mx-auto">
            <CardContent className="p-8">
              <h4 className="font-heading font-bold text-white text-2xl mb-4 uppercase">
                Local Law Group: Streamlining Legal Operations with AI
              </h4>
              <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                Local Law Group's attorneys were spending countless hours on document review, client intake, and case
                research, leaving less time for high-value legal strategy and client representation.
              </p>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                Our solution involved building a custom AI assistant that automated document processing, client
                screening, and legal research tasks, allowing attorneys to focus on complex legal work.
              </p>

              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div className="text-center">
                  <div className="text-primary text-4xl font-bold mb-2">38%</div>
                  <p className="text-white font-semibold">more time on legal strategy</p>
                  <p className="text-muted-foreground text-sm">Automated document review & client intake</p>
                </div>
                <div className="text-center">
                  <div className="text-primary text-4xl font-bold mb-2">$42K</div>
                  <p className="text-white font-semibold">saved on paralegal costs</p>
                  <p className="text-muted-foreground text-sm">Reduced manual research & documentation</p>
                </div>
              </div>

              <blockquote className="text-white text-lg italic text-center border-l-4 border-primary pl-6">
                "Aether transformed our practice. Our attorneys can now focus on what they do best - providing
                exceptional legal counsel to our clients."
                <footer className="text-muted-foreground text-base mt-2">- Managing Partner, Local Law Group</footer>
              </blockquote>
            </CardContent>
          </Card>
        </div>

        {/* Testimonials */}
        <div className="mb-20">
          <h3 className="font-heading font-bold text-white text-3xl md:text-4xl text-center mb-12 uppercase">
            What Our Clients Say
          </h3>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-black border-white border-2 rounded-lg">
                <CardContent className="p-6">
                  <blockquote className="text-white text-lg mb-4 leading-relaxed">"{testimonial.quote}"</blockquote>
                  <footer className="text-muted-foreground">- {testimonial.author}</footer>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div className="text-center">
          <h3 className="font-heading font-bold text-white text-3xl md:text-4xl mb-6 uppercase">
            Let's talk about how AI can 10x your operations
          </h3>
          <p className="text-muted-foreground text-xl mb-8">Book your free AI audit and see what's possible.</p>
          <Button className="border-2 border-primary bg-transparent text-white px-8 py-4 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200">
            Book Your Free AI Audit
          </Button>
        </div>
      </div>
    </section>
  )
}
