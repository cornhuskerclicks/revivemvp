import Link from "next/link"

export function Footer() {
  const links = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "Leadership", href: "/leadership" },
    { name: "AI", href: "/ai" },
    { name: "Marketing", href: "/marketing" },
    { name: "Contact", href: "/contact" },
  ]

  return (
    <footer id="contact" className="bg-black py-12 px-6 border-t border-[#2A2A2A]">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap justify-center items-center gap-8 mb-8">
          {links.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className="text-white hover:text-primary transition-colors duration-200 text-sm uppercase tracking-wide"
            >
              {link.name}
            </Link>
          ))}
        </div>

        <div className="text-center text-[#CFCFCF] text-sm space-y-2">
          <p>© 2025 Aether Consulting. All rights reserved.</p>
          <p>Aether Consulting is a trade name of Cornhusker Clicks LLC.</p>
        </div>
      </div>
    </footer>
  )
}
