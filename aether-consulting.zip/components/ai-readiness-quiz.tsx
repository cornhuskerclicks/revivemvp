"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle2, ChevronDown, ChevronUp } from "lucide-react"

type Answer = string | string[]

interface QuizData {
  [key: string]: Answer
}

export function AIReadinessQuiz() {
  const [isOpen, setIsOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<QuizData>({})
  const [showResults, setShowResults] = useState(false)

  const steps = [
    {
      title: "Tell us a bit about your business",
      questions: [
        {
          id: "q1",
          text: "What best describes your business?",
          type: "single",
          options: ["Product-based", "Service-based", "SaaS/Tech", "Franchise/Multi-location", "Other"],
        },
        {
          id: "q2",
          text: "How many people work in your business?",
          type: "single",
          options: ["Just me", "2–10", "11–50", "51–100", "100+"],
        },
        {
          id: "q3",
          text: "How well are your systems documented?",
          type: "single",
          options: [
            "Not at all – everything is in people's heads",
            "Some documentation exists",
            "Well-documented SOPs and workflows",
          ],
        },
      ],
    },
    {
      title: "How your systems work today",
      questions: [
        {
          id: "q4",
          text: "Do you have a central CRM or customer database?",
          type: "single",
          options: [
            "No",
            "Sort of — spreadsheets or basic tools",
            "Yes, but it's underutilized",
            "Yes, fully used and integrated",
          ],
        },
        {
          id: "q5",
          text: "How do you currently generate leads? (Select all that apply)",
          type: "multiple",
          options: ["Word of mouth", "Paid ads", "Website/SEO", "Referrals", "Cold outreach", "Inconsistent or none"],
        },
        {
          id: "q6",
          text: "What do you currently automate? (Select all that apply)",
          type: "multiple",
          options: [
            "Lead follow-up",
            "Email nurture",
            "Sales pipeline",
            "Onboarding",
            "Task delegation",
            "Nothing yet",
          ],
        },
      ],
    },
    {
      title: "Your current experience with AI",
      questions: [
        {
          id: "q7",
          text: "How familiar are you with AI tools?",
          type: "single",
          options: [
            "Never used them",
            "Played around with ChatGPT",
            "Use AI occasionally",
            "AI is part of daily workflows",
            "Building or investing in AI",
          ],
        },
        {
          id: "q8",
          text: "Do you have repetitive tasks AI could help with?",
          type: "single",
          options: ["Yes, a lot", "A few", "Not sure", "Already automated most things"],
        },
        {
          id: "q9",
          text: "Which areas would you like AI to improve? (Pick up to 3)",
          type: "multiple",
          maxSelections: 3,
          options: [
            "Lead generation",
            "Customer service",
            "Sales follow-up",
            "Marketing content",
            "Admin tasks",
            "Reporting/analysis",
            "Onboarding/training",
            "None",
          ],
        },
      ],
    },
    {
      title: "What would AI enable for your business?",
      questions: [
        {
          id: "q10",
          text: "What would saving 5–10 hours a week mean to your business?",
          type: "single",
          options: ["Game-changing", "Helpful", "Not much"],
        },
        {
          id: "q11",
          text: "How ready are you to explore AI strategically?",
          type: "single",
          options: ["Very ready — I just need the plan", "Curious but cautious", "Not ready yet"],
        },
      ],
    },
    {
      title: "Let's get your score — and your strategy",
      questions: [
        {
          id: "q12",
          text: "What's your biggest business challenge right now?",
          type: "text",
        },
        {
          id: "q13",
          text: "What's your first name?",
          type: "input",
        },
        {
          id: "q14",
          text: "Last name",
          type: "input",
        },
        {
          id: "q15",
          text: "Business name",
          type: "input",
        },
        {
          id: "q16",
          text: "Email",
          type: "input",
          inputType: "email",
        },
        {
          id: "q17",
          text: "Phone (optional)",
          type: "input",
          inputType: "tel",
          optional: true,
        },
      ],
    },
  ]

  const handleAnswer = (questionId: string, value: string, isMultiple: boolean, maxSelections?: number) => {
    if (isMultiple) {
      const currentAnswers = (answers[questionId] as string[]) || []
      const isSelected = currentAnswers.includes(value)

      if (isSelected) {
        setAnswers({
          ...answers,
          [questionId]: currentAnswers.filter((v) => v !== value),
        })
      } else {
        if (maxSelections && currentAnswers.length >= maxSelections) {
          return
        }
        setAnswers({
          ...answers,
          [questionId]: [...currentAnswers, value],
        })
      }
    } else {
      setAnswers({
        ...answers,
        [questionId]: value,
      })
    }
  }

  const isStepComplete = () => {
    const currentQuestions = steps[currentStep].questions
    return currentQuestions.every((q) => {
      if (q.optional) return true
      const answer = answers[q.id]
      if (q.type === "multiple") {
        return Array.isArray(answer) && answer.length > 0
      }
      return answer && answer !== ""
    })
  }

  const calculateScore = () => {
    let score = 0

    // Q3: Documentation
    if (answers.q3 === "Well-documented SOPs and workflows") score += 2
    else if (answers.q3 === "Some documentation exists") score += 1

    // Q4: CRM
    if (answers.q4 === "Yes, fully used and integrated") score += 2
    else if (answers.q4 === "Yes, but it's underutilized") score += 1

    // Q6: Automation
    const q6Answers = answers.q6 as string[]
    if (q6Answers && q6Answers.length > 0 && !q6Answers.includes("Nothing yet")) {
      score += Math.min(q6Answers.length, 2)
    }

    // Q7: AI Familiarity
    if (answers.q7 === "Building or investing in AI") score += 2
    else if (answers.q7 === "AI is part of daily workflows") score += 2
    else if (answers.q7 === "Use AI occasionally") score += 1

    // Q8: Repetitive tasks
    if (answers.q8 === "Yes, a lot") score += 2
    else if (answers.q8 === "A few") score += 1

    // Q10: Time savings impact
    if (answers.q10 === "Game-changing") score += 2
    else if (answers.q10 === "Helpful") score += 1

    // Q11: Readiness
    if (answers.q11 === "Very ready — I just need the plan") score += 2
    else if (answers.q11 === "Curious but cautious") score += 1

    return score
  }

  const getResultMessage = (score: number) => {
    if (score <= 4) {
      return {
        title: "You've Got Massive Potential",
        message:
          "You've got massive potential — but some key systems need strengthening before AI can create ROI. Let's map out a growth-first strategy.",
        cta: "Build Your Foundation",
      }
    } else if (score <= 8) {
      return {
        title: "You're On The Edge Of A Breakthrough",
        message:
          "You're on the edge of a breakthrough — this is the perfect time for a focused AI Readiness Audit to unlock results.",
        cta: "Get Your AI Audit",
      }
    } else {
      return {
        title: "You're Ready For AI",
        message:
          "You're ready — and the ROI from smart AI integration could be significant. Let's get you a plan that actually works.",
        cta: "Build Your AI Strategy",
      }
    }
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
      window.scrollTo({ top: 0, behavior: "smooth" })
    } else {
      setShowResults(true)
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const handleClose = () => {
    setIsOpen(false)
    setCurrentStep(0)
    setAnswers({})
    setShowResults(false)
  }

  if (!isOpen) {
    return (
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Is Your Business Ready for AI?</h2>
          <p className="text-xl text-gray-400 mb-10 text-pretty max-w-2xl mx-auto">
            Take the free 2-minute quiz to discover where you stand — and what to fix first.
          </p>
          <Button
            onClick={() => setIsOpen(true)}
            className="bg-transparent border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-6 text-lg font-semibold rounded-lg transition-all duration-300"
          >
            Start Quiz
            <ChevronDown className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>
    )
  }

  if (showResults) {
    const score = calculateScore()
    const result = getResultMessage(score)

    return (
      <section className="py-32 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-end mb-4">
            <button onClick={handleClose} className="text-gray-400 hover:text-white transition-colors">
              <ChevronUp className="w-6 h-6" />
            </button>
          </div>
          <Card className="bg-black border-primary">
            <CardContent className="p-12 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 border-2 border-primary mb-8">
                <CheckCircle2 className="w-10 h-10 text-primary" />
              </div>

              <h2 className="text-4xl md:text-5xl font-bold mb-4">{result.title}</h2>
              <div className="text-6xl font-bold text-primary mb-8">{score}/11</div>
              <p className="text-xl text-gray-300 mb-12 leading-relaxed max-w-2xl mx-auto">{result.message}</p>

              <div className="border-t border-gray-800 pt-8 mb-8">
                <p className="text-2xl font-semibold mb-6">
                  Want us to review your quiz and build your custom roadmap?
                </p>
              </div>

              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 px-10 py-5 text-lg font-semibold rounded-lg transition-all duration-300">
                Schedule Your Free Discovery Call
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    )
  }

  const currentStepData = steps[currentStep]

  return (
    <section className="py-32 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-between items-start mb-6">
            <div className="flex-1" />
            <h2 className="text-3xl md:text-4xl font-bold text-balance flex-1">Is Your Business Ready for AI?</h2>
            <div className="flex-1 flex justify-end">
              <button onClick={handleClose} className="text-gray-400 hover:text-white transition-colors">
                <ChevronUp className="w-6 h-6" />
              </button>
            </div>
          </div>
          <p className="text-gray-400 text-pretty max-w-2xl mx-auto">
            Take the free 2-minute quiz to discover where you stand — and what to fix first.
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-gray-400">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm text-gray-400">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        <Card className="bg-black border-white hover:border-primary transition-all duration-300">
          <CardContent className="p-8 md:p-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">{currentStepData.title}</h2>

            <div className="space-y-10">
              {currentStepData.questions.map((question) => (
                <div key={question.id} className="space-y-4">
                  <label className="text-lg font-semibold block">
                    {question.text}
                    {question.optional && <span className="text-gray-500 text-sm ml-2">(optional)</span>}
                  </label>

                  {question.type === "single" && question.options && (
                    <div className="space-y-3">
                      {question.options.map((option) => (
                        <button
                          key={option}
                          onClick={() => handleAnswer(question.id, option, false)}
                          className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-300 ${
                            answers[question.id] === option
                              ? "border-primary bg-primary/10 text-white"
                              : "border-gray-700 hover:border-gray-600 text-gray-300"
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  )}

                  {question.type === "multiple" && question.options && (
                    <div className="space-y-3">
                      {question.maxSelections && (
                        <p className="text-sm text-gray-400">Select up to {question.maxSelections}</p>
                      )}
                      {question.options.map((option) => {
                        const isSelected = (answers[question.id] as string[])?.includes(option)
                        return (
                          <button
                            key={option}
                            onClick={() => handleAnswer(question.id, option, true, question.maxSelections)}
                            className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-300 ${
                              isSelected
                                ? "border-primary bg-primary/10 text-white"
                                : "border-gray-700 hover:border-gray-600 text-gray-300"
                            }`}
                          >
                            <div className="flex items-center">
                              <div
                                className={`w-5 h-5 rounded border-2 mr-3 flex items-center justify-center ${
                                  isSelected ? "border-primary bg-primary" : "border-gray-600"
                                }`}
                              >
                                {isSelected && <CheckCircle2 className="w-4 h-4 text-black" />}
                              </div>
                              {option}
                            </div>
                          </button>
                        )
                      })}
                    </div>
                  )}

                  {question.type === "text" && (
                    <Textarea
                      value={(answers[question.id] as string) || ""}
                      onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })}
                      className="bg-gray-900 border-gray-700 focus:border-primary text-white min-h-32"
                      placeholder="Tell us about your biggest challenge..."
                    />
                  )}

                  {question.type === "input" && (
                    <Input
                      type={question.inputType || "text"}
                      value={(answers[question.id] as string) || ""}
                      onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })}
                      className="bg-gray-900 border-gray-700 focus:border-primary text-white"
                      placeholder={question.text}
                    />
                  )}
                </div>
              ))}
            </div>

            <div className="flex gap-4 mt-12">
              {currentStep > 0 && (
                <Button
                  onClick={handleBack}
                  variant="outline"
                  className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800 hover:border-gray-600 py-6 text-lg bg-transparent"
                >
                  Back
                </Button>
              )}
              <Button
                onClick={handleNext}
                disabled={!isStepComplete()}
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed py-6 text-lg font-semibold"
              >
                {currentStep === steps.length - 1 ? "Get My Results" : "Next"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
