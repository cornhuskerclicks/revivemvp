"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  const scrollToJourney = () => {
    const element = document.getElementById("journey")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section
      id="hero"
      className="min-h-screen bg-black flex flex-col items-center justify-center text-center px-6 py-24"
    >
      <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white uppercase mb-8 text-balance max-w-6xl leading-tight">
        Where Strategy Meets Systems.
      </h1>

      <p className="text-white text-xl md:text-2xl mb-12 max-w-4xl text-pretty leading-relaxed">
        Leadership. Intelligence. Execution.
        <br />
        Aether Consulting helps founders scale with clarity, automation, and performance.
      </p>

      <Button
        onClick={scrollToJourney}
        size="lg"
        className="border-2 border-primary bg-transparent text-white px-10 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
      >
        Start Your Journey
      </Button>

      <div className="mt-16 max-w-5xl">
        <p className="text-white/50 text-sm uppercase tracking-wider mb-6 font-semibold">Results</p>
        <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-8 text-white/80">
          <div className="flex items-center gap-2 text-sm md:text-base">
            <span className="font-medium">Rock Choir</span>
            <span className="text-white/50">£1.8m</span>
            <ArrowRight className="w-4 h-4 text-primary" />
            <span className="text-primary font-semibold">£9m</span>
          </div>

          <div className="hidden md:block w-px h-8 bg-white/20" />

          <div className="flex items-center gap-2 text-sm md:text-base">
            <span className="font-medium">GoHenry</span>
            <span className="text-white/50">startup</span>
            <ArrowRight className="w-4 h-4 text-primary" />
            <span className="text-white/70">£39.3m</span>
            <ArrowRight className="w-4 h-4 text-primary" />
            <span className="text-primary font-semibold">acquisition</span>
          </div>

          <div className="hidden md:block w-px h-8 bg-white/20" />

          <div className="flex items-center gap-2 text-sm md:text-base">
            <span className="font-medium">Freed By Real Estate</span>
            <span className="text-primary font-semibold">tens of millions</span>
            <span className="text-white/70">in investment</span>
          </div>
        </div>
      </div>
    </section>
  )
}
