"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-black/90 backdrop-blur-sm" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <Image src="/aether-consulting-logo.png" alt="Aether Consulting" width={120} height={120} />
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-white hover:text-primary transition-colors duration-200">
              Home
            </Link>
            <Link href="/leadership" className="text-white hover:text-primary transition-colors duration-200">
              Leadership
            </Link>
            <Link href="/ai" className="text-white hover:text-primary transition-colors duration-200">
              AI
            </Link>
            <Link href="/marketing" className="text-white hover:text-primary transition-colors duration-200">
              Marketing
            </Link>
            <Link href="/about" className="text-white hover:text-primary transition-colors duration-200">
              About
            </Link>
            <Link href="/contact" className="text-white hover:text-primary transition-colors duration-200">
              Contact
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}
