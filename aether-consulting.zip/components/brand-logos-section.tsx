"use client"

import Image from "next/image"

const brands = [
  // Row 1
  {
    name: "Disney+",
    logo: "/images/brands/disney-plus.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Disney%2B_logo.svg-PzOAtsJyxxSOOYl5qxTw1oEJTT159s.png",
    needsBackground: true, // Dark blue logo needs light background
  },
  {
    name: "Time Inc.",
    logo: "/images/brands/time-inc.svg",
    url: "https://blobs.vusercontent.net/blob/Time_Inc._logo-7cisO9zuTHS8F4GUSwXpBlzONmzzYb.svg",
    needsBackground: true, // Red logo benefits from background
  },
  {
    name: "Sprout Social",
    logo: "/images/brands/sprout-social.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Sprout-Social-Logo-Vertical-Lockup-2x-e1621359247773-yA9mXkzOpDeYY9QCX7mxe8YDgHqUTE.png",
    needsBackground: true, // Green and black logo needs background
  },
  {
    name: "ChemTec",
    logo: "/images/brands/chemtec.svg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChemTec-Logo-tY20R6pKWJHTuzzGY1G81xd8EVfRsJ.svg",
    needsBackground: true,
  },
  {
    name: "Refinery29",
    logo: "/images/brands/refinery29.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/refinery29-logo-png-1-300x211-1-6UTdVuuJk5ZiLpwhpOiJSLI4ZTeJLT.png",
    needsBackground: true,
  },
  // Row 2
  {
    name: "KSI",
    logo: "/images/brands/ksi.jpg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ksi-Rvygm6VNf1vrIgp7YvDjJPU1CB5uQx.jpg",
  },
  {
    name: "Perez Hilton",
    logo: "/images/brands/perez-hilton.jpg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/perez-smartfeed-logo-scaled-HtrDxIMqWI3inFt9mqIB23iPn3Kgki.jpg",
  },
  {
    name: "America's Next Top Model",
    logo: "/images/brands/top-model.jpg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/p187482_b_v8_ah-Uj9P3cH10yoBvA5qQo3yPZzubXcUgj.jpg",
  },
  {
    name: "Argos",
    logo: "/images/brands/argos.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Argos_logo.svg-OMaBA1prMFme8dUy6yMFZbT8SXi4mH.png",
  },
  {
    name: "The Coop",
    logo: "/images/brands/the-coop.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/The_Coop_Logo-LNnWXjZO67Ovsmhvj3DwTL6EHTJfFq.png",
  },
  // Row 3
  {
    name: "Soft Card",
    logo: "/images/brands/soft-card.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/download-6tlQCs50I5TKIlxF3bmLCMEp1hXeX8.png",
  },
  {
    name: "Summit Performance",
    logo: "/images/brands/summit-performance.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo_SP_colour-YvsLZCuXTG5kEQIeDfWW1guDfhMxdg.webp",
  },
  {
    name: "Noire Ink London",
    logo: "/images/brands/noire-ink.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/N%20ink-jaEMJj5FokpChjEIrZO91xCtvVEQHs.webp",
  },
  {
    name: "Smith Pauley Attorneys",
    logo: "/images/brands/smith-pauley.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Smith-Pauley-Logo-Stacked-2023-RBfOlpvQvzciXlKEvNJzUaj0WCmSd7.webp",
    needsBackground: true,
  },
  {
    name: "Party Pieces",
    logo: "/images/brands/party-pieces.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/PP-o6i95VKczaqcP8ye5n5ki4rvqIXavH.png",
  },
  // Row 4
  {
    name: "People's Revolution",
    logo: "/images/brands/peoples-revolution.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/peoples_revolution_logo_high_quality-QQt5hPue3eg2wzaIvLAb6kz2G04Ftj.webp",
  },
  {
    name: "Freed Real Estate",
    logo: "/images/brands/freed-real-estate.jpg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/freed_by_real_estate_logo-CeL6g5lYFU6aNet2YG0jS2MAl7x6QW.jpg",
    needsBackground: true,
  },
  {
    name: "No Regrets",
    logo: "/images/brands/nr-icon.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/nr-icon-1-yJ1DSw3jfz5PV6NjumpQJmip70hBrU.png",
  },
  {
    name: "National Trust",
    logo: "/images/brands/national-trust.svg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/national-trust-2-oH0SbXh54upn62F5vRG3FkO2ca1bfl.svg",
    needsBackground: true,
  },
  {
    name: "Overhang",
    logo: "/images/brands/overhang.png",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/download%20%281%29-VsmYoDz4M9sytLgR4l3QtJIrAi6FE9.png",
  },
]

export function BrandLogosSection() {
  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Trusted by Leading Brands</h2>
          <p className="text-lg text-gray-400">Proud to have worked with industry leaders across multiple sectors</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {brands.map((brand) => (
            <div
              key={brand.name}
              className="group relative aspect-square flex items-center justify-center p-6 bg-white/5 rounded-lg border border-white/10 hover:border-white/20 transition-all duration-300"
            >
              <div className={`relative w-full h-full ${brand.needsBackground ? "bg-white rounded-md p-3" : ""}`}>
                <Image
                  src={brand.url || "/placeholder.svg"}
                  alt={brand.name}
                  fill
                  className="object-contain transition-all duration-300 grayscale group-hover:grayscale-0 opacity-60 group-hover:opacity-100"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
