"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export function JourneySection() {
  const router = useRouter()

  const tiles = [
    {
      id: "leadership",
      title: "Aether Leadership",
      description: "Fractional CMOs and brand consultants helping founders scale with clarity and confidence.",
      cta: "Explore Leadership",
      path: "/leadership",
    },
    {
      id: "ai",
      title: "Aether AI",
      description: "Intelligent systems and automation that power modern business growth.",
      cta: "Explore AI",
      path: "/ai",
    },
    {
      id: "marketing",
      title: "Aether Marketing",
      description: "SEO, PPC, websites, and campaigns designed to perform.",
      cta: "Explore Marketing",
      path: "/marketing",
    },
  ]

  return (
    <section id="journey" className="bg-black py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="font-heading font-bold text-white text-3xl md:text-4xl lg:text-5xl text-center mb-20 uppercase text-balance">
          Choose Your Path
        </h2>

        <div className="grid md:grid-cols-3 gap-10">
          {tiles.map((tile) => (
            <Card
              key={tile.id}
              className="bg-[#111111] border-2 border-[#2A2A2A] rounded-lg cursor-pointer group transition-all duration-300 hover:border-primary hover:-translate-y-1"
            >
              <CardContent className="p-10 text-center flex flex-col h-full">
                <h3 className="font-heading font-bold text-white text-xl md:text-2xl mb-6 uppercase group-hover:text-primary transition-colors duration-300">
                  {tile.title}
                </h3>
                <p className="text-[#CFCFCF] text-base md:text-lg mb-8 leading-relaxed flex-grow">{tile.description}</p>
                <Button
                  onClick={() => router.push(tile.path)}
                  className="border-2 border-primary bg-transparent text-white px-6 py-3 rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
                >
                  {tile.cta}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
