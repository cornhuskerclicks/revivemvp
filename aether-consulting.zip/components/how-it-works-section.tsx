import { Button } from "@/components/ui/button"

export function HowItWorksSection() {
  const steps = [
    {
      icon: "calendar",
      title: "Book a Consultation",
      description: "Identify your path",
    },
    {
      icon: "document",
      title: "Get Your Growth Plan",
      description: "Strategy tailored to your goals",
    },
    {
      icon: "rocket",
      title: "Execute with Experts",
      description: "Implement and scale",
    },
  ]

  const IconComponent = ({ type }: { type: string }) => {
    switch (type) {
      case "calendar":
        return (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-10 h-10">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
            <line x1="16" y1="2" x2="16" y2="6"></line>
            <line x1="8" y1="2" x2="8" y2="6"></line>
            <line x1="3" y1="10" x2="21" y2="10"></line>
          </svg>
        )
      case "document":
        return (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-10 h-10">
            <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2Z"></path>
            <polyline points="14,2 14,8 20,8"></polyline>
            <line x1="16" y1="13" x2="8" y2="13"></line>
            <line x1="16" y1="17" x2="8" y2="17"></line>
            <polyline points="10,9 9,9 8,9"></polyline>
          </svg>
        )
      case "rocket":
        return (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-10 h-10">
            <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path>
            <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path>
            <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path>
            <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path>
          </svg>
        )
      default:
        return null
    }
  }

  return (
    <section className="bg-[#111111] py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <h2 className="font-heading font-bold text-white text-3xl md:text-4xl lg:text-5xl text-center mb-16 uppercase text-balance">
          A Simple 3-Step Process
        </h2>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-6 text-black">
                <IconComponent type={step.icon} />
              </div>
              <h3 className="font-heading font-bold text-white text-xl mb-3 uppercase">{step.title}</h3>
              <p className="text-[#CFCFCF] text-lg leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button
            size="lg"
            className="border-2 border-primary bg-transparent text-white px-8 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
          >
            Schedule a Call
          </Button>
        </div>
      </div>
    </section>
  )
}
