import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ThankYouPage() {
  return (
    <main className="bg-black min-h-screen">
      <Navigation />

      <section className="min-h-screen bg-black digital-mesh flex flex-col items-center justify-center text-center px-6 py-24">
        <div className="max-w-3xl mx-auto">
          <div className="text-6xl mb-8">✅</div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white uppercase mb-8 text-balance leading-tight">
            Thank You!
          </h1>

          <p className="text-white text-xl md:text-2xl mb-12 max-w-2xl mx-auto text-pretty leading-relaxed">
            Your message has been received. Our team will reach out within one business day to discuss how we can help
            transform your business.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-10 py-6 text-lg font-semibold rounded-lg"
            >
              <Link href="/">Return Home</Link>
            </Button>

            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10 px-10 py-6 text-lg font-semibold rounded-lg bg-transparent"
            >
              <Link href="/about">Learn More About Us</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
