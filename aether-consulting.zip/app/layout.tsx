import type React from "react"
import type { Metadata } from "next"
import { Poppins, Inter } from "next/font/google"
import { Suspense } from "react"
import "./globals.css"

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["700"],
  variable: "--font-poppins",
  display: "swap",
})

const inter = Inter({
  subsets: ["latin"],
  weight: ["400"],
  variable: "--font-inter",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Aether Consulting - Where Strategy Meets Systems",
  description:
    "Leadership. Intelligence. Execution. Aether Consulting helps founders scale with clarity, automation, and performance.",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${poppins.variable} ${inter.variable} font-sans antialiased bg-black text-white`}>
        <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
        <script
          dangerouslySetInnerHTML={{
            __html: `window.CHAT_ORIGIN='https://nextjs-boilerplate-three-rust-42.vercel.app';`,
          }}
        />
        <script src="https://nextjs-boilerplate-three-rust-42.vercel.app/widget.js" defer></script>
      </body>
    </html>
  )
}
