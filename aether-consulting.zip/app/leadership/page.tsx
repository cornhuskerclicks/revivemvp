import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function LeadershipPage() {
  return (
    <main className="bg-black min-h-screen text-white">
      <Navigation />

      <section className="min-h-screen bg-black flex flex-col items-center justify-center text-center px-6 py-24">
        <h1 className="font-heading text-5xl md:text-6xl lg:text-7xl font-bold text-white uppercase mb-8 text-balance max-w-6xl leading-tight">
          Leadership That Powers Growth
        </h1>
        <p className="text-white text-xl md:text-2xl mb-6 max-w-4xl text-pretty leading-relaxed">
          You lead the vision. We build the system.
        </p>
        <p className="text-white text-lg md:text-xl mb-12 max-w-3xl text-pretty leading-relaxed">
          Fractional CMO and AI-powered brand consulting for founders who want clarity, authority, and scalable systems.
        </p>
        <Button
          size="lg"
          className="border-2 border-primary bg-transparent text-white px-10 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
        >
          Schedule a Leadership Call
        </Button>
      </section>

      {/* Meet Your Leadership Team */}
      <section className="py-20 px-6 bg-[#111111]">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-16 text-center text-balance">
            Meet Your Leadership Team
          </h2>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Adam Stacey */}
            <Card className="bg-[#111111] border-2 border-primary p-8 h-full flex flex-col">
              <h3 className="font-heading text-2xl font-bold text-white mb-2">Adam Stacey</h3>
              <p className="text-primary mb-6 text-lg">Fractional CMO & Brand Architect</p>

              <div className="space-y-4 text-secondary-foreground leading-relaxed flex-grow">
                <p>
                  With over 20 years building and scaling brands, Adam Stacey helps founders move from chaos to clarity.
                </p>
                <p>
                  He is the creator of the <strong className="text-white">3C Storytelling™ System</strong> — a framework
                  that aligns Clarity, Connection, and Conviction so every message moves people and every strategy
                  scales.
                </p>
                <p>
                  Adam combines deep marketing strategy with leadership discipline. He builds systems that let your
                  brand grow without you needing to run every campaign.
                </p>

                <div className="pt-4">
                  <h4 className="text-white font-semibold mb-3">Specialties:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>Strategic brand positioning & messaging (StoryBrand + 3C Storytelling™)</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>Go-to-market clarity and campaign architecture</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>Leadership systems, team alignment, and execution planning</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>Data-driven growth frameworks that turn vision into measurable performance</span>
                    </li>
                  </ul>
                </div>

                <p className="pt-4 italic text-white border-l-4 border-primary pl-4">
                  Core belief: You don't need to be louder — you need to be aligned.
                </p>
              </div>
            </Card>

            {/* Nathan Magnussen */}
            <Card className="bg-[#111111] border-2 border-primary p-8 h-full flex flex-col">
              <h3 className="font-heading text-2xl font-bold text-white mb-2">Nathan Magnussen</h3>
              <p className="text-primary mb-6 text-lg">Personal Brand & AI Strategist</p>

              <div className="space-y-4 text-secondary-foreground leading-relaxed flex-grow">
                <p>Nathan helps founders turn their story into a scalable system.</p>
                <p>
                  He blends personal brand strategy, AI automation, and digital storytelling to create influence that
                  compounds.
                </p>
                <p>
                  As a consultant and builder, he designs intelligent ecosystems that attract leads, nurture trust, and
                  convert at scale.
                </p>

                <div className="pt-4">
                  <h4 className="text-white font-semibold mb-3">Specialties:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>Personal brand development & content strategy</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>AI-powered lead generation and automation systems</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>Authority-building through storytelling and thought leadership</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>CRM design and nurture sequences that sell while you sleep</span>
                    </li>
                  </ul>
                </div>

                <p className="pt-4 italic text-white border-l-4 border-primary pl-4">
                  Core belief: When your message leads, AI and automation amplify your impact.
                </p>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Leadership Philosophy */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-8 text-balance">
            Clarity First. Systems Always. Scale Forever.
          </h2>

          <div className="space-y-4 text-lg text-secondary-foreground mb-12 leading-relaxed">
            <p>Most brands chase tactics.</p>
            <p>We start with clarity — your voice, message, and market position.</p>
            <p>Then we build systems that scale — from funnels and automation to campaigns and team rhythm.</p>
            <p className="text-xl text-white font-semibold pt-4">
              You don't just get a consultant. You get a leadership team that grows your brand with precision and
              purpose.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <Card className="bg-[#111111] border-2 border-primary p-8 text-center transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <div className="text-4xl mb-4">🟦</div>
              <h3 className="font-heading text-xl font-bold text-white mb-3">Clarity</h3>
              <p className="text-secondary-foreground">Define the message that drives every move.</p>
            </Card>

            <Card className="bg-[#111111] border-2 border-primary p-8 text-center transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <div className="text-4xl mb-4">🟣</div>
              <h3 className="font-heading text-xl font-bold text-white mb-3">Connection</h3>
              <p className="text-secondary-foreground">Build a voice people trust and follow.</p>
            </Card>

            <Card className="bg-[#111111] border-2 border-primary p-8 text-center transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <div className="text-4xl mb-4">🔺</div>
              <h3 className="font-heading text-xl font-bold text-white mb-3">Conviction</h3>
              <p className="text-secondary-foreground">Lead with systems that deliver consistent growth.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Who We Serve */}
      <section className="py-20 px-6 bg-[#111111]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-16 text-center text-balance">
            We Partner With Founders Who Want to Scale Themselves Out
          </h2>

          <div className="space-y-4 text-lg text-secondary-foreground mb-12 leading-relaxed">
            <p>You've built momentum. Now you need a leadership team to scale your vision.</p>

            <div className="text-left max-w-2xl mx-auto mt-8 space-y-4">
              <p className="font-semibold text-white">We work with:</p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="text-primary mr-3 mt-1">→</span>
                  <span>Founders and CEOs earning $500K–$10M who want to move from founder-led to brand-led</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3 mt-1">→</span>
                  <span>Leaders ready to align messaging, marketing, and systems under one strategy</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3 mt-1">→</span>
                  <span>Businesses seeking AI-powered efficiency without losing authenticity</span>
                </li>
              </ul>
            </div>

            <p className="text-xl text-white font-semibold pt-8">
              We bring the strategy, structure, and storytelling your next chapter demands.
            </p>
          </div>
        </div>
      </section>

      {/* The Aether Leadership Blueprint */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-16 text-center text-balance">
            The Aether Leadership Blueprint
          </h2>
          <p className="text-xl text-secondary-foreground mb-12 text-center">How We Scale Together</p>

          <div className="space-y-8">
            <Card className="bg-[#111111] border-2 border-primary p-8 transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <div className="flex items-start gap-6">
                <div className="text-4xl font-bold text-primary flex-shrink-0">1</div>
                <div>
                  <h3 className="font-heading text-2xl font-bold text-white mb-3">Audit & Alignment</h3>
                  <p className="text-secondary-foreground leading-relaxed">
                    We uncover your growth bottlenecks — from message to funnel to team cadence. You gain clarity on
                    what's working, what's missing, and what comes next.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="bg-[#111111] border-2 border-primary p-8 transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <div className="flex items-start gap-6">
                <div className="text-4xl font-bold text-primary flex-shrink-0">2</div>
                <div>
                  <h3 className="font-heading text-2xl font-bold text-white mb-3">90-Day Strategy Sprint</h3>
                  <p className="text-secondary-foreground leading-relaxed">
                    We co-create a leadership roadmap — messaging, marketing architecture, and automation systems
                    aligned to your goals.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="bg-[#111111] border-2 border-primary p-8 transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <div className="flex items-start gap-6">
                <div className="text-4xl font-bold text-primary flex-shrink-0">3</div>
                <div>
                  <h3 className="font-heading text-2xl font-bold text-white mb-3">Implementation & Partnership</h3>
                  <p className="text-secondary-foreground leading-relaxed">
                    Adam steps in as your Fractional CMO. Nathan builds your personal brand and AI systems. Together, we
                    integrate and execute.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="bg-[#111111] border-2 border-primary p-8 transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <div className="flex items-start gap-6">
                <div className="text-4xl font-bold text-primary flex-shrink-0">4</div>
                <div>
                  <h3 className="font-heading text-2xl font-bold text-white mb-3">Scale & Optimize</h3>
                  <p className="text-secondary-foreground leading-relaxed">
                    We refine, automate, and transfer ownership so your brand runs smoothly — with or without you.
                  </p>
                </div>
              </div>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Button
              size="lg"
              className="border-2 border-primary bg-transparent text-white px-8 py-6 text-lg rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
            >
              Start Your Leadership Sprint
            </Button>
          </div>
        </div>
      </section>

      {/* Results That Speak */}
      <section className="py-20 px-6 bg-[#111111]">
        <div className="max-w-5xl mx-auto">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-16 text-center text-balance">
            Leadership That Delivers Real Growth
          </h2>

          <p className="text-xl text-secondary-foreground mb-12 text-center">
            Our clients move from guesswork to growth — guided by strategy, story, and systems.
          </p>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="bg-[#111111] border-2 border-primary p-6 text-center transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <p className="text-secondary-foreground">
                Scaled <strong className="text-white">Rock Choir</strong> from local concept to national brand
              </p>
            </Card>

            <Card className="bg-[#111111] border-2 border-primary p-6 text-center transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <p className="text-secondary-foreground">
                Repositioned <strong className="text-white">GoHenry</strong> pre-acquisition through clarity-led
                marketing
              </p>
            </Card>

            <Card className="bg-[#111111] border-2 border-primary p-6 text-center transition-all duration-300 hover:border-primary hover:-translate-y-1">
              <p className="text-secondary-foreground">
                Built brand-led systems for agencies and founders achieving{" "}
                <strong className="text-white">3–5X ROI</strong>
              </p>
            </Card>
          </div>

          <Card className="bg-[#111111] border-2 border-primary p-8">
            <p className="text-xl text-secondary-foreground italic text-center leading-relaxed">
              "We finally stopped chasing tactics. Adam and Nathan gave us clarity, a strategy that works, and systems
              that scale."
            </p>
            <p className="text-center text-secondary-foreground mt-4">— Client Testimonial</p>
          </Card>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-heading text-4xl md:text-6xl font-bold text-white mb-6 text-balance">
            Lead With Clarity. Scale With Confidence.
          </h2>

          <p className="text-xl text-secondary-foreground mb-4">Your next level needs more than marketing.</p>
          <p className="text-xl text-secondary-foreground mb-8">It needs leadership.</p>

          <p className="text-lg text-secondary-foreground mb-8">Let's map your growth engine together.</p>

          <Button
            size="lg"
            className="border-2 border-primary bg-transparent text-white px-8 py-6 text-lg rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
          >
            Schedule a Leadership Call
          </Button>
        </div>
      </section>

      <Footer />
    </main>
  )
}
