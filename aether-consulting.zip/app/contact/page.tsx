"use client"
import { useEffect } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export default function ContactPage() {
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const utmFields = ["utm_source", "utm_medium", "utm_campaign"]

    utmFields.forEach((field) => {
      const element = document.getElementById(field) as HTMLInputElement
      if (element) {
        element.value = params.get(field) || ""
      }
    })
  }, [])

  return (
    <main className="bg-black min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="min-h-screen bg-black digital-mesh flex flex-col items-center justify-center text-center px-6 py-24">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white uppercase mb-8 text-balance max-w-6xl leading-tight">
          Let's Build What's Next
        </h1>

        <p className="text-white text-xl md:text-2xl mb-12 max-w-4xl text-pretty leading-relaxed">
          Tell us about your business and where you want to go.
          <br />
          We'll bring the clarity, strategy, and systems to help you get there.
        </p>
      </section>

      {/* Contact Form Section */}
      <section className="bg-black py-20 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Start the Conversation</h2>
            <p className="text-gray-300 text-lg">
              Fill out the form and our team will be in touch within 1 business day.
            </p>
          </div>

          <form id="contactForm" method="POST" action="/api/zap" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="firstName" className="text-white text-sm font-medium mb-2 block">
                  First Name *
                </Label>
                <Input
                  id="firstName"
                  name="firstName"
                  type="text"
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary"
                  placeholder="John"
                />
              </div>

              <div>
                <Label htmlFor="lastName" className="text-white text-sm font-medium mb-2 block">
                  Last Name *
                </Label>
                <Input
                  id="lastName"
                  name="lastName"
                  type="text"
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary"
                  placeholder="Doe"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="company" className="text-white text-sm font-medium mb-2 block">
                Company
              </Label>
              <Input
                id="company"
                name="company"
                type="text"
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary"
                placeholder="Your company"
              />
            </div>

            <div>
              <Label htmlFor="email" className="text-white text-sm font-medium mb-2 block">
                Email *
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                required
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <Label htmlFor="phone" className="text-white text-sm font-medium mb-2 block">
                Phone
              </Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary"
                placeholder="+1 (555) 123-4567"
              />
            </div>

            <div>
              <Label htmlFor="message" className="text-white text-sm font-medium mb-2 block">
                Message *
              </Label>
              <Textarea
                id="message"
                name="message"
                required
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-primary min-h-[150px]"
                placeholder="Tell us about your business and what you're looking to achieve..."
              />
            </div>

            <div>
              <Label className="text-white text-sm font-medium mb-4 block">Interested In *</Label>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="leadership"
                    name="interested"
                    value="Leadership"
                    className="w-4 h-4 rounded border-white/30 bg-white/5 text-primary focus:ring-primary focus:ring-offset-0"
                  />
                  <Label htmlFor="leadership" className="text-white cursor-pointer">
                    Leadership
                  </Label>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="ai"
                    name="interested"
                    value="AI"
                    className="w-4 h-4 rounded border-white/30 bg-white/5 text-primary focus:ring-primary focus:ring-offset-0"
                  />
                  <Label htmlFor="ai" className="text-white cursor-pointer">
                    AI
                  </Label>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="marketing"
                    name="interested"
                    value="Marketing"
                    className="w-4 h-4 rounded border-white/30 bg-white/5 text-primary focus:ring-primary focus:ring-offset-0"
                  />
                  <Label htmlFor="marketing" className="text-white cursor-pointer">
                    Marketing
                  </Label>
                </div>
              </div>
            </div>

            <input type="hidden" name="utm_source" id="utm_source" />
            <input type="hidden" name="utm_medium" id="utm_medium" />
            <input type="hidden" name="utm_campaign" id="utm_campaign" />

            <input type="text" name="bot_field" style={{ display: "none" }} tabIndex={-1} autoComplete="off" />

            <input type="hidden" name="redirect" value="https://v0-aether-consulting.vercel.app/thank-you" />

            <Button
              type="submit"
              size="lg"
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground px-10 py-6 text-lg font-semibold rounded-lg"
            >
              Submit Inquiry
            </Button>
          </form>
        </div>
      </section>

      {/* Contact Details Section */}
      <section className="bg-black py-20 px-6 border-t border-white/10">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-white text-center mb-16">Our Offices</h2>

          <div className="grid md:grid-cols-2 gap-12">
            {/* USA HQ */}
            <div className="bg-gradient-to-br from-primary/10 to-purple-500/10 border border-white/10 rounded-lg p-8">
              <h3 className="text-2xl font-bold text-white mb-6">USA HQ</h3>
              <div className="space-y-4 text-gray-300">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">📍</span>
                  <p className="text-lg">17838 Burke St, Omaha, NE 68118</p>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">📞</span>
                  <a href="tel:+14022011144" className="text-lg hover:text-primary transition-colors">
                    +1 (402)-201-1144
                  </a>
                </div>
              </div>
            </div>

            {/* UK Office */}
            <div className="bg-gradient-to-br from-purple-500/10 to-primary/10 border border-white/10 rounded-lg p-8">
              <h3 className="text-2xl font-bold text-white mb-6">UK Office</h3>
              <div className="space-y-4 text-gray-300">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">📍</span>
                  <p className="text-lg">Henleaze House, 13 Harpury Road, Bristol BS9 4PN</p>
                </div>
              </div>
            </div>
          </div>

          {/* Closing Line */}
          <div className="mt-16 text-center">
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed text-pretty">
              We're a global, family-led consulting team — and we treat every client like one of our own. Let's start
              your journey with clarity, connection, and conviction.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
