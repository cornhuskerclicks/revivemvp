import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { JourneySection } from "@/components/journey-section"
import { AboutSection } from "@/components/about-section"
import { HowItWorksSection } from "@/components/how-it-works-section"
import { BrandLogosSection } from "@/components/brand-logos-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main className="bg-black min-h-screen">
      <Navigation />
      <HeroSection />
      <JourneySection />
      <AboutSection />
      <HowItWorksSection />
      <BrandLogosSection />
      <Footer />
    </main>
  )
}
