import { Button } from "@/components/ui/button"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ArrowRight, Globe, Heart, Shield, Sparkles, Target, Users } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />

      <section className="min-h-screen bg-black digital-mesh flex flex-col items-center justify-center text-center px-6 py-24">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white uppercase mb-8 text-balance max-w-6xl leading-tight">
          Where Legacy Meets Innovation
        </h1>
        <p className="text-white text-xl md:text-2xl mb-12 max-w-4xl text-pretty leading-relaxed">
          Aether Consulting is built on family, forged through experience, and fueled by the next generation of strategy
          and systems. We help founders build businesses that scale like families — rooted in trust, clarity, and shared
          success.
        </p>
        <Button
          size="lg"
          className="border-2 border-primary bg-transparent text-white px-10 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
        >
          Join the Aether Family
        </Button>
      </section>

      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-primary text-balance text-center">
            From Local Roots to Global Vision
          </h2>
          <div className="space-y-6 text-lg text-gray-300 leading-relaxed text-center max-w-4xl mx-auto">
            <p className="text-pretty">
              Our story began decades ago — guided by hard-earned experience in leadership, marketing, and brand
              strategy. We've built and scaled companies across industries and continents.
            </p>
            <p className="text-pretty">
              Today, Aether Consulting unites global perspective with next-generation innovation — blending the wisdom
              of experience with the agility of AI, automation, and personal brand strategy.
            </p>
            <p className="text-xl font-semibold text-white text-balance">
              We're not just a consultancy. We're a family-led team helping founders create businesses that last.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <h3 className="text-2xl font-bold text-primary mb-2 text-balance">Legacy meets leadership.</h3>
            </div>
            <div className="text-center p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <h3 className="text-2xl font-bold text-primary mb-2 text-balance">Systems meet storytelling.</h3>
            </div>
            <div className="text-center p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <h3 className="text-2xl font-bold text-primary mb-2 text-balance">Vision meets velocity.</h3>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-primary text-balance text-center">
            Experience You Can Trust. Innovation You Can Feel.
          </h2>
          <p className="text-xl text-gray-300 mb-12 leading-relaxed text-pretty text-center max-w-4xl mx-auto">
            Our leadership blends the seasoned strategic mind of a Fractional CMO with the cutting-edge perspective of a
            new generation fluent in AI, personal branding, and digital ecosystems.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <Target className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl font-bold mb-2 text-balance">Decades of strategic marketing leadership</h3>
                  <p className="text-gray-400 text-pretty">Proven frameworks that have scaled businesses globally</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <Sparkles className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl font-bold mb-2 text-balance">Modern AI and automation expertise</h3>
                  <p className="text-gray-400 text-pretty">Cutting-edge tools that multiply your impact</p>
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <Users className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl font-bold mb-2 text-balance">Personal brand strategy that builds authority</h3>
                  <p className="text-gray-400 text-pretty">Position yourself as the go-to expert in your field</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <Globe className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl font-bold mb-2 text-balance">
                    Storytelling frameworks that turn messages into movements
                  </h3>
                  <p className="text-gray-400 text-pretty">Connect deeply with your audience and drive action</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 p-8 bg-black rounded-lg border border-primary">
            <p className="text-2xl font-bold text-center text-balance">
              It's the balance every founder needs:
              <br />
              <span className="text-primary">Strategy rooted in experience. Execution built for tomorrow.</span>
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-primary text-balance text-center">
            We Treat Clients Like Family
          </h2>
          <p className="text-xl text-gray-300 mb-12 leading-relaxed text-pretty text-center max-w-4xl mx-auto">
            When you work with us, you don't just get consultants — you gain partners. We see your business as an
            extension of our own, and your mission becomes part of ours.
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <Heart className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3 text-balance">Trust First</h3>
              <p className="text-gray-400 text-pretty">We build relationships that last longer than projects.</p>
            </div>

            <div className="p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <Sparkles className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3 text-balance">Clarity Always</h3>
              <p className="text-gray-400 text-pretty">Every recommendation serves your mission, not ours.</p>
            </div>

            <div className="p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <Target className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3 text-balance">Systems That Serve</h3>
              <p className="text-gray-400 text-pretty">
                We design processes that free your time and multiply your impact.
              </p>
            </div>

            <div className="p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <Globe className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3 text-balance">Global Perspective</h3>
              <p className="text-gray-400 text-pretty">We bring international insight to every strategy.</p>
            </div>

            <div className="p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <Shield className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3 text-balance">Family Spirit</h3>
              <p className="text-gray-400 text-pretty">We lead with empathy, integrity, and loyalty.</p>
            </div>

            <div className="p-6 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <Users className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3 text-balance">Growth is Personal</h3>
              <p className="text-gray-400 text-pretty">Great businesses are built like great families.</p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-2xl font-semibold text-gray-300 text-balance max-w-4xl mx-auto">
              We believe growth is personal.
              <br />
              And great businesses are built like great families — on shared purpose and mutual respect.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-primary text-balance text-center">
            A Name That Reflects Our Purpose
          </h2>
          <div className="max-w-4xl mx-auto space-y-6 text-lg text-gray-300 leading-relaxed">
            <p className="text-pretty">
              In ancient philosophy, Aether represented the element that filled the heavens — the unseen force
              connecting everything.
            </p>
            <p className="text-xl font-semibold text-white text-balance">
              That's what we build for our clients: connection — between brand and audience, vision and execution, story
              and system.
            </p>
            <p className="text-2xl font-bold text-primary mt-8 text-balance">
              We exist to help leaders find clarity, build conviction, and scale with confidence.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center text-primary text-balance">
            To Build Brands That Outlast Their Founders
          </h2>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="p-8 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <h3 className="text-2xl font-bold mb-4 text-primary text-balance">
                Step out of the noise and into narrative
              </h3>
              <p className="text-gray-400 text-pretty">
                Cut through the clutter with a story that resonates and converts
              </p>
            </div>
            <div className="p-8 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <h3 className="text-2xl font-bold mb-4 text-primary text-balance">Replace chaos with clarity</h3>
              <p className="text-gray-400 text-pretty">Transform confusion into a clear path forward</p>
            </div>
            <div className="p-8 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <h3 className="text-2xl font-bold mb-4 text-primary text-balance">
                Build systems that scale without burnout
              </h3>
              <p className="text-gray-400 text-pretty">Grow your business without sacrificing your life</p>
            </div>
            <div className="p-8 bg-black rounded-lg border border-white hover:border-primary transition-colors">
              <h3 className="text-2xl font-bold mb-4 text-primary text-balance">
                Create legacies that live beyond them
              </h3>
              <p className="text-gray-400 text-pretty">Build something that lasts and makes a lasting impact</p>
            </div>
          </div>

          <div className="text-center p-8 bg-black rounded-lg border border-primary">
            <p className="text-2xl font-bold text-balance">
              We believe in businesses that serve people, brands that tell truth, and systems that amplify good.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-black">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 text-primary text-balance">Join the Aether Family</h2>
          <p className="text-xl text-gray-300 mb-8 leading-relaxed text-pretty">
            We don't just want clients.
            <br />
            We want partners who believe in purpose, people, and progress.
          </p>
          <p className="text-2xl font-semibold text-white mb-8 text-balance">
            Let's build your growth engine — together.
          </p>
          <Button
            size="lg"
            className="border-2 border-primary bg-transparent text-white px-10 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
          >
            Book a Strategy Call
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
