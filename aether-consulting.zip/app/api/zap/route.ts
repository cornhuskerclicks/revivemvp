import { type NextRequest, NextResponse } from "next/server"

// Zapier/Make webhook proxy endpoint - Updated to trigger fresh build

export async function POST(request: NextRequest) {
  try {
    console.log("[v0] Form submission received")

    console.log("[v0] Checking environment variables...")
    console.log("[v0] ZAPIER_WEBHOOK_URL exists:", !!process.env.ZAPIER_WEBHOOK_URL)
    console.log("[v0] MAKE_WEBHOOK_URL exists:", !!process.env.MAKE_WEBHOOK_URL)
    console.log(
      "[v0] All env keys:",
      Object.keys(process.env).filter(
        (key) => key.includes("WEBHOOK") || key.includes("ZAPIER") || key.includes("MAKE"),
      ),
    )

    const contentType = request.headers.get("content-type") || ""
    let body: Record<string, any>

    // Parse request body based on content type
    if (contentType.includes("application/json")) {
      body = await request.json()
      console.log("[v0] Parsed JSON body:", body)
    } else if (
      contentType.includes("multipart/form-data") ||
      contentType.includes("application/x-www-form-urlencoded")
    ) {
      const formData = await request.formData()
      body = Object.fromEntries(formData)
      console.log("[v0] Parsed form data:", body)
    } else {
      console.log("[v0] Unsupported content type:", contentType)
      return NextResponse.json({ error: "Unsupported content type" }, { status: 400 })
    }

    // Honeypot spam protection
    if (body.bot_field || body.website || body.url || body.honeypot) {
      console.log("[v0] Spam detected via honeypot field")
      return NextResponse.json({ success: true, message: "Form submitted successfully" })
    }

    // Get webhook URL from environment variable
    const webhookUrl = process.env.ZAPIER_WEBHOOK_URL || process.env.ZAPIER_HOOK_URL || process.env.MAKE_WEBHOOK_URL

    if (!webhookUrl) {
      console.error("[v0] No webhook URL configured in environment variables")
      console.error(
        "[v0] Available env vars with WEBHOOK/ZAPIER/MAKE:",
        Object.keys(process.env).filter(
          (key) =>
            key.toUpperCase().includes("WEBHOOK") ||
            key.toUpperCase().includes("ZAPIER") ||
            key.toUpperCase().includes("MAKE"),
        ),
      )
      return NextResponse.json(
        {
          error: "Webhook not configured",
          details: "Please add ZAPIER_WEBHOOK_URL, ZAPIER_HOOK_URL, or MAKE_WEBHOOK_URL to environment variables",
        },
        { status: 500 },
      )
    }

    console.log("[v0] Sending to webhook:", webhookUrl.substring(0, 30) + "...")

    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })

    console.log("[v0] Webhook response status:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Webhook request failed:", response.status, errorText)
      return NextResponse.json(
        {
          error: "Failed to submit form",
          details: `Webhook returned ${response.status}`,
          webhookError: errorText,
        },
        { status: 500 },
      )
    }

    const responseData = await response.text()
    console.log("[v0] Webhook response:", responseData)

    // Handle redirect if specified
    if (body.redirect) {
      return NextResponse.redirect(body.redirect)
    }

    return NextResponse.json({ success: true, message: "Form submitted successfully" })
  } catch (error) {
    console.error("[v0] Error processing form submission:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
