import { NextResponse } from "next/server"

export async function GET() {
  // Get all environment variable keys that might be related to webhooks
  const webhookKeys = Object.keys(process.env).filter(
    (key) =>
      key.toUpperCase().includes("WEBHOOK") ||
      key.toUpperCase().includes("ZAPIER") ||
      key.toUpperCase().includes("MAKE") ||
      key.toUpperCase().includes("HOOK"),
  )

  const zapierHookUrl = process.env.ZAPIER_HOOK_URL
  const zapierWebhookUrl = process.env.ZAPIER_WEBHOOK_URL
  const makeWebhookUrl = process.env.MAKE_WEBHOOK_URL

  // Show first 50 env keys to help debug
  const allKeys = Object.keys(process.env).slice(0, 50)

  return NextResponse.json({
    hasZapierHookUrl: !!zapierHookUrl,
    hasZapierWebhook: !!zapierWebhookUrl,
    hasMakeWebhook: !!makeWebhookUrl,
    webhookRelatedKeys: webhookKeys,
    zapierHookValue: zapierHookUrl ? `${zapierHookUrl.substring(0, 30)}...` : "not set",
    zapierWebhookValue: zapierWebhookUrl ? `${zapierWebhookUrl.substring(0, 30)}...` : "not set",
    allEnvKeys: Object.keys(process.env).length,
    sampleKeys: allKeys, // Show first 50 keys to verify what's loaded
  })
}
