import { NextResponse } from "next/server"

export async function GET() {
  const knowledge = {
    company: {
      name: "Aether Consulting",
      legalEntity: "Trade name of Cornhusker Clicks LLC",
      tagline: "We turn fragmented marketing into a unified growth engine: Storytelling (3C) × Systems × AI",
      promise: "One simple promise: one message, one system, one goal — profitable scale",
      positioning:
        "Endorsed personal brand: you work directly with Adam. Aether is the framework + system + partner bench under his direction",
      mission: "Help founders scale with clarity, automation, and performance",
      philosophy: "Build brands that outlast their founders. Transform businesses from founder-led to brand-led",
    },

    leadership: {
      adam: {
        name: "Adam Stacey",
        title: "Fractional CMO",
        creator: "3C Storytelling™ System",
        experience: "20+ years in digital growth; built award-winning agencies",
        author: "3 I'd Monster™ (2024)",
        knownFor: "Clear strategy, budget discipline, and execution that compounds",
        approach: "Builds brand systems that work without the founder (not personality-dependent)",
        pillars: "Clarity, Connection, Conviction + Systems & AI",
        bio: "Founder of Aether Consulting and creator of the 3C Storytelling™ System. Built award-winning agencies and led growth for consumer, SaaS/FinTech, and real estate brands. Author of 3 I'd Monster™ (2024). Known for clear strategy, budget discipline, and systems that scale beyond the founder.",
      },
      nathan: {
        name: "Nathan (Nate)",
        title: "Chief Connections & AI",
        description: "Super-connector and AI operator",
        specialisms: [
          "Brand amplification",
          "Partnerships",
          "Database reactivation (LeadAwake AI)",
          "GHL automations",
          "Event/network growth",
        ],
        expertise:
          "Turns dormant lists into revenue with respectful, on-brand messaging. Builds simple funnels, tight CRMs, and follow-up that actually closes",
        bio: "Super-connector and AI operator. Builds partnership motion, database reactivation, and the automations that keep pipelines moving. Focused on GHL, messaging, and simple funnels that convert.",
      },
    },

    idealClient: {
      description:
        "£/$1–10m founders who want predictable, scalable, trackable growth and are ready to align messaging, funnels, and ops",
      revenue: "$1M-$10M",
      readiness: "Ready to align messaging, funnels, and operations",
    },

    problemsSolved: [
      "Fragmented marketing, noisy funnels, 'random acts' of content",
      "Founder-dependent sales/brand",
      "Underused CRM and follow-up",
      "No simple plan, no KPIs, no accountability",
    ],

    frameworks: {
      storytelling: {
        name: "3C Storytelling™",
        components: [
          {
            name: "Clarity",
            description: "Say the right thing to the right people",
            includes: [
              "Offer architecture",
              "Value prop",
              "Homepage wireframe",
              "Messaging guide",
              "Define ICP, pains, outcomes, proof",
            ],
          },
          {
            name: "Connection",
            description: "Show proof and build trust at every touch",
            includes: [
              "Content system",
              "Case studies",
              "4:1 helpful-to-ask cadence",
              "Channels + cadence that compound (owned + partner + community)",
            ],
          },
          {
            name: "Conviction",
            description: "A simple, measurable plan",
            includes: [
              "KPIs, reviews, dashboards",
              "Automation and friction-removal",
              "Sales enablement and hand-offs that actually close",
            ],
          },
        ],
      },
      ninetyDaySprint: {
        name: "90-Day Sprint Process",
        weeks: [
          {
            phase: "Week 0-1: Clarity",
            activities: "ICP, offers, proof, homepage wireframe; sprint metrics & dashboards",
          },
          {
            phase: "Week 2-3: Systems",
            activities: "GHL pipelines, forms, calendars, automations; analytics",
          },
          {
            phase: "Week 4-5: Connection",
            activities: "Content cadence (4:1 helpful:ask), proof assets, SEO/ad direction",
          },
          {
            phase: "Week 6-10: Scale",
            activities: "Launch campaigns, LeadAwake AI™, partnerships, PR moments",
          },
          {
            phase: "Week 11-12: Review & Next Sprint",
            activities: "KPI review, wins, bottlenecks; refine the plan; decide on next sprint",
          },
        ],
      },
    },

    services: {
      fractionalCMO: {
        name: "Fractional CMO (Adam-led)",
        outcome: "One message, one system, one plan — executed weekly",
        includes: [
          "3C Messaging & Offer Architecture",
          "90-day Sprint Plan + KPIs",
          "Funnel & CRM setup (GHL)",
          "Content/Proof engine (4:1 helpful:ask)",
          "Ad/SEO direction (as needed)",
          "Weekly leadership cadence + dashboards",
        ],
        pricing: {
          monthly: "$12,500/month (starts Day 1 of service)",
          sprintUpfront: "$30,000 for 90 days (preferred)",
        },
      },
      brandAIConsulting: {
        name: "Brand & AI Consulting (Adam + Nate)",
        includes: [
          "AETHER™ AI Readiness Audit + roadmap",
          "LeadAwake AI™ reactivation launch",
          "CRM + automation tune-up (GHL)",
          "Website/funnel updates (V0 + GHL)",
        ],
        pricing: "$5,000-$15,000 per scoped engagement",
      },
      leadAwakeAI: {
        name: "LeadAwake AI™ — Pay-for-Results",
        description:
          "We re-engage your database. You only pay on profits generated from reactivated leads (rev-share, agreed in advance)",
        includes: "Compliant messaging, routing, and attribution",
      },
      coaching: {
        name: "Build-With-You Coaching (3C + AI)",
        description: "For founders/teams who want to learn while building",
        includes: "Weekly working sessions, templates, and reviews",
        options: "Can bundle into Fractional CMO or run standalone",
        community: {
          foundations: "Free: core tools and education",
          accessAccountability: "$99/month: direct Q&A, prompts, and reviews",
          pro: "Application: certified/CMO-level work",
        },
      },
    },

    aiSystemsLayer: {
      leadAwakeAI: {
        name: "LeadAwake AI™",
        description: "Database reactivation: revive dormant leads with compliant, friendly outreach",
        model: "Pay-for-results option available",
      },
      aetherAIAudit: {
        name: "AETHER™ AI Readiness & Audit",
        description: "Gap analysis across data, processes, messaging, and stack",
        deliverables: "Roadmap + quick-wins",
      },
      ghlAutomations: {
        name: "GHL Automations",
        includes: "Forms, calendars, pipelines, SMS/email sequences, tasks, and reporting",
      },
      webFunnels: {
        name: "Web + Funnels",
        stack: "V0/Next + GHL",
        approach: "Simple patterns that load fast and convert",
      },
      dashboards: {
        name: "Dashboards",
        focus: "Revenue-centric views (not vanity metrics)",
      },
    },

    techStack: [
      "V0/Next/Vercel",
      "GoHighLevel",
      "Zapier/Make",
      "OpenAI",
      "Google Workspace",
      "Calendly (or GHL calendars)",
    ],

    proofExperience: [
      {
        client: "GoHenry",
        result: "From startup to £39.3m revenue and toward acquisition (leadership and growth systems support)",
      },
      {
        client: "Rock Choir",
        result: "Scaled programs and marketing operations",
      },
      {
        client: "Titan Real Estate",
        type: "Real Estate",
      },
      {
        client: "Freed By Real Estate",
        type: "Real Estate",
      },
      {
        client: "Smith Pauley",
        type: "Professional Services",
      },
      {
        client: "Ecoscapes",
        type: "Home Services",
      },
      {
        client: "Black Key Homes",
        type: "Real Estate",
      },
      {
        client: "Renaissance Financial",
        type: "FinTech",
      },
      {
        client: "Summit Performance Labs",
        type: "Education",
      },
    ],

    industries: ["Consumer", "SaaS/FinTech", "Professional Services", "Real Estate", "Education", "Home Services"],

    coachingEducation: {
      certification: "3C Storytelling™ certification path (Practitioner)",
      aiAuditTraining: "AETHER™ AI Audit training + quiz tool for lead capture",
      templates: ["Clarity Messaging Doc", "12-month content map", "GHL workflows", "Dashboards", "SOPs"],
      podcasts: {
        main: "Clarity & Conviction (7-10 min)",
        shorts: "Tactical shorts (2-4 min)",
      },
    },

    workingWithUs: [
      "Plain English. Short, clear steps",
      "One plan. No bloated decks; working docs and dashboards",
      "Hands-on. We implement or quarterback your team",
      "Owner view. Budgets tracked; revenue outcomes matter most",
    ],

    howWeWork: {
      leadership: "I lead strategy and weekly cadence",
      team: "I 'bring the bench' when needed (Nate for Connections/AI; Lucy for Social/Storytelling; trusted partners for delivery)",
      execution: "We execute in 90-day sprints with clear KPIs",
    },

    faq: [
      {
        question: "What starts first?",
        answer: "A 30-min discovery. If aligned, we map a 90-day sprint with KPIs",
      },
      {
        question: "Can you work with our existing agency/team?",
        answer: "Yes. We lead strategy and systems; we collaborate or fill gaps",
      },
      {
        question: "Do you do pay-for-results?",
        answer: "For database reactivation (LeadAwake AI™), yes. Else, sprint retainer",
      },
      {
        question: "Do you replace our CRM?",
        answer:
          "Not necessarily. We often standardize on GHL for speed. If you're on HubSpot/Salesforce, we integrate and keep it simple",
      },
      {
        question: "How fast to value?",
        answer:
          "Quick wins in weeks 2-4 (forms, calendars, reactivation, homepage clarity). Compounding results over 90 days",
      },
    ],

    graceGuidelines: {
      tone: "Calm, confident, clear; helpful and direct",
      always: [
        "Clarify the goal",
        "Propose the next step",
        "If qualified, offer booking (use the site's booking link) after collecting name + email",
        "Use 3C in answers",
      ],
      never: "Never invent case studies, numbers, or timelines. If unsure, say so and suggest the next step",
      defaultCTA: "Book a 30-min discovery or Request the AI Readiness Audit",
    },

    contact: {
      cta: "Let's align your message and build a growth engine",
      bookingAction: "Book a 30-min discovery",
      offices: {
        usa: {
          location: "17838 Burke St, Omaha, NE 68118",
          phone: "+1 (402)-201-1144",
        },
        uk: {
          location: "Henleaze House, 13 Harpury Road, Bristol BS9 4PN",
        },
      },
    },

    nameMeaning:
      "In ancient philosophy, Aether represented the element that filled the heavens — the unseen force connecting everything. Aether Consulting builds connection between brand and audience, vision and execution, story and system",
  }

  return NextResponse.json(knowledge)
}
