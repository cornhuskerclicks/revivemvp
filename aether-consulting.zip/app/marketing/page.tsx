import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { BrandLogosSection } from "@/components/brand-logos-section"
import { ArrowRight, CheckCircle2, Zap, TrendingUp, MessageSquare, Globe, BarChart3 } from "lucide-react"

export default function MarketingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />

      {/* Hero Section */}
      <section className="min-h-screen bg-black flex flex-col items-center justify-center text-center px-6 py-24">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white uppercase mb-8 text-balance max-w-6xl leading-tight">
          Marketing That Converts, Scales, and Performs
        </h1>
        <p className="text-white text-xl md:text-2xl mb-12 max-w-4xl text-pretty leading-relaxed">
          We build marketing engines — funnels, ads, SEO, and automations — designed to drive predictable growth and
          measurable ROI.
        </p>
        <Button
          size="lg"
          className="border-2 border-primary bg-transparent text-white px-10 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
        >
          Book a Marketing Strategy Call
        </Button>
      </section>

      {/* Why Aether Marketing */}
      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-center">Why Aether Marketing</h2>
          <h3 className="text-2xl md:text-3xl font-semibold mb-16 text-center text-gray-400">
            From Noise to Numbers — And Numbers to Scale
          </h3>

          <div className="max-w-4xl mx-auto space-y-12">
            {/* Block 1 – The Problem */}
            <div className="space-y-4">
              <p className="text-lg text-gray-300 leading-relaxed">
                Most businesses don't fail because of bad products —
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">they fail because their marketing is fragmented.</p>
              <p className="text-lg text-gray-300 leading-relaxed">
                Disconnected campaigns, inconsistent messaging, and shallow tactics create noise, not growth.
              </p>
            </div>

            <div className="border-t border-[#2A2A2A]" />

            {/* Block 2 – The Solution */}
            <div className="space-y-4">
              <p className="text-lg text-gray-300 leading-relaxed">
                At Aether Marketing, we bring <span className="text-primary font-semibold">clarity</span>.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                We turn your marketing from a collection of tactics into a unified growth engine —
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                one message, one system, one goal: profitable scale.
              </p>
            </div>

            <div className="border-t border-[#2A2A2A]" />

            {/* Block 3 – The Method */}
            <div className="space-y-4">
              <p className="text-lg text-gray-300 leading-relaxed">
                We believe growth happens when strategy and systems work together.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                Every campaign — ads, funnels, SEO, automation — operates as part of a single,{" "}
                <span className="text-primary font-semibold">connected</span> machine.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                Every click, lead, and customer becomes part of a journey that compounds results.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed mt-6">
                Our foundation is storytelling that sells, powered by the{" "}
                <span className="text-[#00B8FF] font-semibold">3C Storytelling™ framework</span>,
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                so every word and campaign speaks with authority and purpose.
              </p>
            </div>

            <div className="border-t border-[#2A2A2A]" />

            {/* Block 4 – The Result */}
            <div className="space-y-6">
              <p className="text-xl text-white font-semibold">
                You don't need more marketing — you need marketing that performs:
              </p>
              <div className="space-y-3 pl-6">
                <p className="text-lg text-gray-300 leading-relaxed">
                  <span className="text-primary font-semibold">Predictable</span> — know what's working
                </p>
                <p className="text-lg text-gray-300 leading-relaxed">
                  <span className="text-primary font-semibold">Scalable</span> — grow with control
                </p>
                <p className="text-lg text-gray-300 leading-relaxed">
                  <span className="text-primary font-semibold">Trackable</span> — measure revenue, not impressions
                </p>
              </div>
            </div>

            <div className="border-t border-[#2A2A2A]" />

            {/* Block 5 – The Promise */}
            <div className="text-center space-y-4 pt-4">
              <p className="text-2xl md:text-3xl font-bold text-white">
                <span className="text-primary">Clear</span>. <span className="text-primary">Connected</span>.{" "}
                <span className="text-primary">Controlled</span>.
              </p>
              <p className="text-xl text-gray-300">Built for growth that lasts.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Services */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-center">
            Everything You Need to Grow, <span className="text-primary">All in One System</span>
          </h2>
          <p className="text-center text-gray-400 mb-12 text-lg">
            We design and manage every part of your marketing engine — built for scale and measured by results.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Service 1 */}
            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 hover:border-primary transition-all duration-300">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-black border-2 border-primary p-3 rounded-lg">
                  <MessageSquare className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Brand Messaging & Storytelling</h3>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                Your message is the foundation. We use our 3C Storytelling™ process to define the story that drives
                every ad, page, and campaign — giving your brand a voice that converts.
              </p>
            </div>

            {/* Service 2 */}
            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 hover:border-primary transition-all duration-300">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-black border-2 border-primary p-3 rounded-lg">
                  <Globe className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Websites & Funnel Architecture</h3>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                Your website is not a brochure — it's a conversion system. We design journeys that guide visitors from
                interest to action, turning traffic into trust.
              </p>
            </div>

            {/* Service 3 */}
            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 hover:border-primary transition-all duration-300">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-black border-2 border-primary p-3 rounded-lg">
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Paid Campaigns (Social & Search)</h3>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                We launch and optimize across Meta, Google, LinkedIn, and TikTok, connecting each campaign to your
                funnel and CRM. Every dollar is tracked. Every lead is nurtured.
              </p>
            </div>

            {/* Service 4 */}
            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 hover:border-primary transition-all duration-300">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-black border-2 border-primary p-3 rounded-lg">
                  <BarChart3 className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">SEO & Digital Growth</h3>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                We deploy AI-powered SEO strategies and organic content systems that increase visibility, authority, and
                inbound demand — sustainably.
              </p>
            </div>

            {/* Service 5 */}
            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 hover:border-primary transition-all duration-300 md:col-span-2">
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-black border-2 border-primary p-3 rounded-lg">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">CRM & Automations</h3>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                We build back-end systems that work while you sleep. From email nurture flows to behavior triggers and
                sales pipelines, every step moves leads closer to conversion.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Who We Serve */}
      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-center">
            For Founders Ready to <span className="text-primary">Scale Without Guesswork</span>
          </h2>
          <p className="text-center text-gray-300 mb-8 text-lg max-w-3xl mx-auto">
            We're not for everyone — we're for the ambitious.
          </p>
          <p className="text-center text-gray-300 mb-12 text-lg max-w-3xl mx-auto">
            We work best with businesses that:
          </p>

          <div className="bg-black p-10 rounded-2xl border-2 border-primary">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <p className="text-gray-300">Have traction but lack a scalable system</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <p className="text-gray-300">Want marketing that runs like a machine</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <p className="text-gray-300">Value clarity, accountability, and measurable ROI</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <p className="text-gray-300">Are ready to invest in systems that deliver consistent results</p>
              </div>
            </div>
            <p className="text-center text-xl font-semibold text-primary mt-8">
              You've built momentum. Now it's time to scale with confidence.
            </p>
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-center">
            The <span className="text-primary">Aether Marketing Engine</span>
          </h2>
          <p className="text-center text-gray-400 mb-12 text-lg">
            Our proven process builds the clarity, systems, and scale your growth demands.
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Step 1 */}
            <div className="relative">
              <div className="bg-black p-8 rounded-2xl border-2 border-primary h-full">
                <div className="text-5xl font-bold text-primary mb-4">1</div>
                <h3 className="text-xl font-bold mb-3">Deep Audit & Gap Analysis</h3>
                <p className="text-gray-300 text-sm leading-relaxed">
                  We dissect your funnels, campaigns, and analytics to identify what's holding you back — and where
                  growth is hiding.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="bg-black p-8 rounded-2xl border-2 border-primary h-full">
                <div className="text-5xl font-bold text-primary mb-4">2</div>
                <h3 className="text-xl font-bold mb-3">Strategic Blueprint Design</h3>
                <p className="text-gray-300 text-sm leading-relaxed">
                  We map your entire marketing engine: Messaging, acquisition, conversion, retention, automation — every
                  piece aligned to your goals.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="bg-black p-8 rounded-2xl border-2 border-primary h-full">
                <div className="text-5xl font-bold text-primary mb-4">3</div>
                <h3 className="text-xl font-bold mb-3">Build, Launch & Iterate</h3>
                <p className="text-gray-300 text-sm leading-relaxed">
                  We build and deploy your systems — websites, funnels, ads, automations — while testing and refining
                  for performance.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="relative">
              <div className="bg-black p-8 rounded-2xl border-2 border-primary h-full">
                <div className="text-5xl font-bold text-primary mb-4">4</div>
                <h3 className="text-xl font-bold mb-3">Scale & Optimize</h3>
                <p className="text-gray-300 text-sm leading-relaxed">
                  We track KPIs, double down on what works, and evolve your system as you grow — creating compounding
                  results over time.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button
              size="lg"
              className="border-2 border-primary bg-transparent text-white px-10 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
            >
              Launch My Marketing Engine
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Results That Speak */}
      <section className="py-20 px-6 bg-black">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-center">
            Growth You Can <span className="text-primary">Measure</span>
          </h2>
          <p className="text-center text-gray-300 mb-12 text-lg">
            Our clients don't just get more traffic — they get results they can count on.
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 text-center">
              <div className="text-5xl font-bold text-primary mb-3">3×</div>
              <p className="text-gray-300">More Leads through unified systems and optimized funnels</p>
            </div>

            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 text-center">
              <div className="text-5xl font-bold text-primary mb-3">40%</div>
              <p className="text-gray-300">Lower Ad Waste by aligning creative with data and audience insights</p>
            </div>

            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 text-center">
              <div className="text-5xl font-bold text-primary mb-3">24/7</div>
              <p className="text-gray-300">Conversions with automated CRM and nurture flows</p>
            </div>

            <div className="bg-black p-8 rounded-2xl border-2 border-white/10 text-center">
              <div className="text-4xl font-bold text-primary mb-3">Predictable</div>
              <p className="text-gray-300">Growth from strategy-led, system-driven marketing</p>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Logos Section */}
      <BrandLogosSection />

      {/* Final CTA */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Let's Build Your <span className="text-primary">Marketing Engine</span>
          </h2>
          <p className="text-xl text-gray-300 mb-4">
            You don't need more noise. You need marketing that performs — systems that grow with you and results you can
            trust.
          </p>
          <p className="text-xl text-gray-300 mb-8">Let's turn your potential into predictable growth.</p>
          <Button
            size="lg"
            className="border-2 border-primary bg-transparent text-white px-10 py-6 text-lg font-semibold rounded-lg hover:bg-primary hover:text-black transition-all duration-200"
          >
            Book a Marketing Strategy Call
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
