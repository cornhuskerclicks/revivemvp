import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AIReadinessQuiz } from "@/components/ai-readiness-quiz"
import { ProofSection } from "@/components/proof-section"
import {
  Briefcase,
  Clock,
  DollarSign,
  Bot,
  Users,
  Calendar,
  FileText,
  Search,
  MessageSquare,
  Settings,
} from "lucide-react"

export default function AIPage() {
  const benefits = [
    {
      icon: <Briefcase className="w-12 h-12 text-primary" />,
      title: "Automate Workflows",
      description: "Automate repetitive workflows",
    },
    {
      icon: <Clock className="w-12 h-12 text-primary" />,
      title: "Save Time",
      description: "Save 10–40 hours per week",
    },
    {
      icon: <DollarSign className="w-12 h-12 text-primary" />,
      title: "Reduce Costs",
      description: "Reduce operating costs fast",
    },
    {
      icon: <Bot className="w-12 h-12 text-primary" />,
      title: "No-Code AI",
      description: "No-code AI, built around your business",
    },
  ]

  const solutions = [
    {
      icon: <Users className="w-8 h-8 text-primary" />,
      title: "Lead Qualifier AI",
      description:
        "Automate the initial screening of leads, ensuring your sales team focuses only on high-potential prospects.",
    },
    {
      icon: <Calendar className="w-8 h-8 text-primary" />,
      title: "Appointment Setting AI",
      description: "Let AI handle scheduling, rescheduling, and reminders, freeing up your team for client engagement.",
    },
    {
      icon: <FileText className="w-8 h-8 text-primary" />,
      title: "Admin/Back Office AI",
      description: "Automate data entry, document processing, and routine administrative tasks to slash overhead.",
    },
    {
      icon: <Search className="w-8 h-8 text-primary" />,
      title: "Listening AI & Lead Scouting",
      description:
        "Our AI scours online groups and platforms to identify keywords, trends, and conversations, finding qualified leads with no ad spend.",
    },
    {
      icon: <MessageSquare className="w-8 h-8 text-primary" />,
      title: "AI Sales Agent & Reactivation",
      description:
        "Deploy an AI sales agent to reactivate dead leads in your database, nurture prospects, and close sales efficiently.",
    },
    {
      icon: <Settings className="w-8 h-8 text-primary" />,
      title: "Custom AI Systems",
      description:
        "Tailored AI solutions built from the ground up to address your unique business challenges and goals.",
    },
  ]

  const testimonials = [
    {
      quote: "Aether AI helped us cut down on manual tasks significantly. Highly recommend!",
      author: "CEO, Tech Startup",
    },
    {
      quote: "Their custom AI solutions are a game-changer for our operations.",
      author: "Operations Director, B2B Services",
    },
    {
      quote: "Seamless integration and excellent support. Our team loves the new AI tools.",
      author: "Founder, E-commerce Brand",
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      <Navigation />

      <main className="relative">
        <section className="relative min-h-screen flex items-center justify-center px-6 py-24">
          {/* Animated Grid Background */}
          <div className="absolute inset-0 opacity-20">
            <div
              className="absolute inset-0 animate-pulse"
              style={{
                backgroundImage: `
                  linear-gradient(rgba(0, 229, 255, 0.1) 1px, transparent 1px),
                  linear-gradient(90deg, rgba(0, 229, 255, 0.1) 1px, transparent 1px)
                `,
                backgroundSize: "60px 60px",
              }}
            />
          </div>

          {/* Floating Nodes */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-primary rounded-full animate-pulse opacity-60"></div>
            <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-primary rounded-full animate-pulse opacity-40 animation-delay-1000"></div>
            <div className="absolute bottom-1/3 left-1/3 w-1.5 h-1.5 bg-primary rounded-full animate-pulse opacity-50 animation-delay-2000"></div>
            <div className="absolute top-2/3 right-1/4 w-1 h-1 bg-primary rounded-full animate-pulse opacity-30 animation-delay-3000"></div>
          </div>

          {/* Connecting Lines */}
          <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="currentColor" stopOpacity="0.2" />
                <stop offset="50%" stopColor="currentColor" stopOpacity="0.6" />
                <stop offset="100%" stopColor="currentColor" stopOpacity="0.2" />
              </linearGradient>
            </defs>
            <line
              x1="25%"
              y1="25%"
              x2="75%"
              y2="33%"
              stroke="url(#lineGradient)"
              strokeWidth="1"
              className="animate-pulse text-primary"
            />
            <line
              x1="33%"
              y1="66%"
              x2="66%"
              y2="25%"
              stroke="url(#lineGradient)"
              strokeWidth="1"
              className="animate-pulse text-primary"
              style={{ animationDelay: "1s" }}
            />
            <line
              x1="75%"
              y1="66%"
              x2="25%"
              y2="75%"
              stroke="url(#lineGradient)"
              strokeWidth="1"
              className="animate-pulse text-primary"
              style={{ animationDelay: "2s" }}
            />
          </svg>

          {/* Hero Content */}
          <div className="relative z-10 max-w-5xl mx-auto text-center">
            {/* Glowing Badge */}
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8 backdrop-blur-sm">
              <div className="w-2 h-2 bg-primary rounded-full mr-2 animate-pulse"></div>
              <span className="text-primary text-sm font-medium">AI-Powered Business Solutions</span>
            </div>

            <h1 className="heading-xl text-6xl md:text-7xl lg:text-8xl mb-12">
              <span className="block bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                Custom AI Agents.
              </span>
              <span className="block bg-gradient-to-r from-primary via-primary/80 to-primary bg-clip-text text-transparent mt-4">
                Real Business Results.
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-300 mb-16 max-w-3xl mx-auto leading-relaxed">
              Slash hours of admin work. Deploy your AI teammate in days. Book your free audit and see what's possible.
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 px-10 py-5 text-lg font-semibold rounded-lg transition-all duration-300">
                Book Free AI Audit
              </Button>
              <Button
                variant="outline"
                className="border-primary/50 text-primary hover:bg-primary/10 hover:border-primary px-10 py-5 text-lg font-semibold rounded-lg backdrop-blur-sm bg-transparent transition-all duration-300"
              >
                Watch Demo
              </Button>
            </div>

            {/* Scroll Indicator */}
            <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center text-gray-400">
              <span className="text-sm mb-2 tracking-wider">SCROLL TO EXPLORE</span>
              <div className="w-px h-8 bg-gradient-to-b from-primary to-transparent animate-pulse"></div>
            </div>
          </div>
        </section>

        {/* AI Readiness Quiz */}
        <AIReadinessQuiz />

        {/* Why Aether AI Section */}
        <section className="py-20 px-6 geometric-overlay">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-20">
              <h2 className="heading-lg text-4xl md:text-5xl mb-8">Why Aether AI?</h2>
              <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
                We help 6-8 figure businesses automate operations, slash overhead, and scale effortlessly by building
                their own AI employees — no coding required.
              </p>
            </div>

            {/* Benefits Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-24">
              {benefits.map((benefit, index) => (
                <div key={index} className="text-center group transition-all duration-300">
                  <div className="flex justify-center mb-6 group-hover:animate-pulse">{benefit.icon}</div>
                  <h3 className="heading-md text-xl mb-4">{benefit.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{benefit.description}</p>
                </div>
              ))}
            </div>

            {/* Trusted By Section */}
            <div className="text-center mb-12">
              <h3 className="heading-md text-3xl mb-6">Trusted by Industry Leaders</h3>
              <p className="text-xl text-gray-300 leading-relaxed">
                Join the companies already transforming their operations with AI
              </p>
            </div>
          </div>
        </section>

        {/* ProofSection */}
        <ProofSection />

        {/* AI Solutions */}
        <section className="py-20 px-6 bg-gray-900/50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-20">
              <h2 className="heading-lg text-4xl md:text-5xl mb-8">Our AI Solutions</h2>
              <p className="text-xl text-gray-300 leading-relaxed">Deploy your AI teammate in days.</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
              {solutions.map((solution, index) => (
                <Card
                  key={index}
                  className="bg-black/50 border-gray-700 transition-all duration-300 hover:border-primary hover:-translate-y-1"
                >
                  <CardContent className="p-8">
                    <div className="flex items-center mb-6">
                      {solution.icon}
                      <h4 className="heading-md text-xl ml-4">{solution.title}</h4>
                    </div>
                    <p className="text-gray-300 leading-relaxed">{solution.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Success Story */}
        <section className="py-20 px-6">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">Success Story</h2>

            <Card className="bg-black/50 border-primary max-w-5xl mx-auto">
              <CardContent className="p-8">
                <h3 className="text-3xl font-bold mb-6">Local Law Group: Streamlining Legal Operations with AI</h3>
                <p className="text-xl text-gray-300 mb-6 leading-relaxed">
                  Local Law Group's attorneys were spending countless hours on document review, client intake, and case
                  research, leaving less time for high-value legal strategy and client representation.
                </p>
                <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                  Our solution involved building a custom AI assistant that automated document processing, client
                  screening, and legal research tasks, allowing attorneys to focus on complex legal work.
                </p>

                <div className="grid md:grid-cols-2 gap-8 mb-8">
                  <div className="text-center">
                    <div className="text-primary text-5xl font-bold mb-2">38%</div>
                    <p className="text-white font-semibold text-lg">more time on legal strategy</p>
                    <p className="text-gray-400">Automated document review & client intake</p>
                  </div>
                  <div className="text-center">
                    <div className="text-primary text-5xl font-bold mb-2">$42K</div>
                    <p className="text-white font-semibold text-lg">saved on paralegal costs</p>
                    <p className="text-gray-400">Reduced manual research & documentation</p>
                  </div>
                </div>

                <blockquote className="text-white text-xl italic text-center border-l-4 border-primary pl-6">
                  "Aether transformed our practice. Our attorneys can now focus on what they do best - providing
                  exceptional legal counsel to our clients."
                  <footer className="text-gray-400 text-lg mt-2">- Managing Partner, Local Law Group</footer>
                </blockquote>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 px-6 bg-gray-900/50">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">What Our Clients Say</h2>
            <p className="text-center text-gray-400 mb-16">Coming soon: Hear from more businesses amplified by AI.</p>

            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="bg-black/50 border-gray-700">
                  <CardContent className="p-6">
                    <blockquote className="text-white text-lg mb-4 leading-relaxed">"{testimonial.quote}"</blockquote>
                    <footer className="text-gray-400">- {testimonial.author}</footer>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="py-20 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="heading-lg text-4xl md:text-5xl mb-8">Let's talk about how AI can 10x your operations</h2>
            <p className="text-xl text-gray-300 mb-12 leading-relaxed">
              Book your free AI audit and see what's possible.
            </p>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 px-10 py-5 text-lg font-semibold rounded-lg transition-all duration-300">
              Book Your Free AI Audit
            </Button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
